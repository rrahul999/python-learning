# makes flexible functions 
# we will study about *args or *operators

# def total(a,b):
#     return a+b
# print(total(3,4)) # for 2 parameters - 2 arguments passed

# def total1(a,b):
#     return a+b
# print(total1(1,2,3,4)) # for 2 parameters - number of arguments passd are more - will give error


# so if we want to pass "n" numbers of argument for unknown number of parameters - we use *oprator ie.- *args
def total3(*args):
    print(args)
    print(type(args))
total3(1,2,3,4) # argument passed here will be passed as a tuple to the "agrs" parameter ##############


# here with the help op * args we can pass n numbers of arguments we want
def add(*args):
    all_total = 0
    for i in args:
        all_total += i
    return all_total
print(add(1,2,3,4,5,6))
