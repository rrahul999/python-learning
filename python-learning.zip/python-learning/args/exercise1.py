# define a function
# takes 2 parameters - normal pareameter and *args
# * args will be iterable ie. list or tuple
# out put will be - *args to the power normal parameter argument - example (num,*args) - (3,*args) - (3,[1,2,3]) - [3,8,27]
# output will be list
# if the user didn't pass any argument - "please pass args" - else - return list


def power_output(num, *args):
    if args:            # to check wether ags is passed or not - true or false 
        return [i**num for i in args]
    else:
        return "pass args"


num1 = [1,2,3]
print(power_output(3,*num1))
print(power_output(3,*[5,6]))
