# # define a function
# input a list as argument
# output - if a given condition in **kwargs is true - list will be in reverse order with first letter capital 
# else the output will be ony the list with first letter capital

def info(list1,**kwargs):
    if kwargs.get("reverse_str") == True:
        return [i[::-1].title() for i in list1]
    else:
        return [i.title() for i in list1]
l = ["rahul","sagar"]
d = {"reverse_str":False}
print(info(l,**d))