# kwargs -  double star ** arguments - actually its a keyword argument
# **kwargs (double star parameter)
# takes keyword argruments - outputs a dictionary

def info(**kwargs):
    print(kwargs)  # output is in key value pair - dictionary
    print(type(kwargs)) # type is dictionary
    for key,value in kwargs.items():  # we can iterate in dictionary
        print(f"{key}:{value}")

info(fname="rahul", lname="kumar") # arguments are passed as keyword argument
d = {"name":"rahul","age":33} # argument for **kwargs parameter
info(**d) # passing argument for **kwargs parameter from any dictionary - dictionary unpacking






def info1(name,**kwargs): # normal parameter is passed
    for key,value in kwargs.items(): 
        print(f"{key}:{value}")

info1("sagar",fname="rahul", lname="kumar") # if we pass normal parameter in function- we have to pass argument for that else - give error
