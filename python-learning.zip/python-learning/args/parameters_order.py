# functions with all parameters
# In any function we pass 4 types of parameters - normal parameters
#                                                 default parameters
#                                                 *args
#                                                 **kwargs

# for using all types of parameters at a time, there is an order - PADK
# normal parameters
# *args
# default parameters
# **kwargs

def func(name,*args,age = 33,**kwargs):
    print(name)
    print(args)
    print(age)
    print(kwargs)
d = {"place":"bokaro","roll":72}
func("rahul",1,2,3,**d)  # here we are not passing any argument for default parameter - already have argument

