# checks if the condition is empty or not (true in case of not empty    and    false in case of empty)


name = "rahul"
if name:        # here the condition is not written, so now it will now check wether the value of the variable is empty or not
    print("string is not empty")
else:
    print("string is  empty")



# if user does not enter the name 
name1 = input("enter name: ")
if name1:
    print(f"{name1}")
else:
    print("please enter name!")