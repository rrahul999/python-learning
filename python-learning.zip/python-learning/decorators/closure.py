# function returning function - also known as "colosure" or "first class function"

# we can make separate function to find out square,cube,power 4......and so on
# but now we will make a single function for all of them - i.e- square,cube power 4......and so on will be done by a single function

def to_power(x): # here x is the value of power we want
    def calc_power(n): # n- number whose square,cube power 4 etc we want to find
        return n**x
    return calc_power

square = to_power(2)
print(square(7))

cube = to_power(3)
print(cube(7))



