# decorators - Enhances the fonctionality of othe functions

def func1():
    print("this is func1")
func1()
def func2():
    print("this is funct2")
func2()
# the output will be - this is func1 - for func1
# the output will be - this is func2 - for func2


# if we want to print an extra same line - "this is awesome function" for both the functions without changing the code
# i.e - we are enhancing the functionality of the functions
# this can be done by using  - decorators
def decorator_func(any_func): # decorator function will take any function(function whose functionality we want to enhance) as parameter
    def wrapper_func(): # wrapper function will add functionality to the function whose functionality we want to enhance
        print("this is awesome function") # this is the functionality which will be added to the function whose functionality we want to enhance
        any_func() # we will run the function whose functionality we want to enhance
    return wrapper_func


var1 = decorator_func(func1) 
# here we will call decorator_func - will return wrapper_func - it will give the functionality first "this is awesome function" - 
# then will give the any_function - which refers to func1
var1() 

var2 = decorator_func(func2)
var2()


# syntactic shugar - @ - use for decorators
@decorator_func # this is shortcut of using decorators --------------------------
def func3():
    print("this is func3")
func3()


