
def decorator_func(any_func): 
    def wrapper_func(*args,**kwargs): # now we can pass any numbers of arguments in "func(a,b,c.....)"
        print("this is awesome function") # this is the functionality which will be added to the function whose functionality we want to enhance
        any_func(*args,**kwargs) # we will run the function whose functionality we want to enhance
    return wrapper_func


# syntactic shugar - @ - use for decorators
@decorator_func # this is shortcut of using decorators --------------------------
def func(a,b):
    print(f"this is func with argument {a}, {b}")
func(7,8) # when we pass argument here - output - wrapper_func() takes 0 positional arguments but 1 was given
# when we call "func()" - actually we are calling wrapper function - so, for this we have to pass parameter in wrapper function





# complete decorator function -------------------------------------------------
def decorator_func2(any_func): 
    def wrapper_func(*args,**kwargs): # now we can pass any numbers of arguments in "func(a,b,c.....)"
        print("this is awesome function") # this is the functionality which will be added to the function whose functionality we want to enhance
        return any_func(*args,**kwargs) # we need to return "any_func" - since we are returning "add" function
    return wrapper_func

@decorator_func2
def add(a,b):
    return a+b # here we are not printing - here we are using return - so we also need to return "any_func"
    # earlier we were using print - which autonatically prints our "any-func"
print(add(2,3))

@decorator_func2 
def func(a,b):
    print(f"this is func with argument2 {a}, {b}")
func(9,10) 

