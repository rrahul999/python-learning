# here we will use "doc string" --------------------

from functools import wraps
def decorator_func(any_func): 
    @wraps(any_func) #before wrapper function we will use inbuilt decorator - @wraps(xyz) - where xyz is the fuction we want to enhance - "any_func"
    def wrapper_func(*args,**kwargs): # now we can pass any numbers of arguments in "func(a,b,c.....)"
        """this is wrapper function"""  # doc string for wrapper function
        print("this is awesome function") # this is the functionality which will be added to the function whose functionality we want to enhance
        return any_func(*args,**kwargs) # we need to return "any_func" - since we are returning "add" function
    return wrapper_func

@decorator_func
def add(a,b):
    '''this is add function''' # doc string for add function
    return a+b # here we are not printing - here we are using return - so we also need to return "any_func"
    # earlier we were using print - which autonatically prints our "any-func"
print(add(2,3))
print(add.__doc__)
# it will give the doc string of the wrapper function instead of add function - because when we call "add" - we are calling "wrapper_func"
print(add.__name__)
# it will give the name of the wrapper function instead of add function - because when we call "add" - we are calling "wrapper_func"

# to solve this problem we will import modules  "import" - at the top - 
# and before wrapper function we will use inbuilt decorator - @wraps(xyz) - where xyz is the fuction we want to enhance - "any_func"
