# make a decorator function and use it on an "add" function
# output should be 1) doc string of the decorator 2) doc string of the add function 3) result of add function

# decorator function -----------------------
from functools import wraps # we import wraps from functools - 
def print_function_decorator(any_func):
    @wraps(any_func) # we use this to print the doc of "add" func
    def wrapper_function(*args,**kwargs):
        """this is wrapper function"""
        print(f"you are calling {any_func.__name__} function")
        print(any_func.__doc__)
        return any_func(*args,**kwargs)
    return wrapper_function

# add function using decorator function ----------
@print_function_decorator
def add(a,b):
    '''this function takes 2 parameters and returns their sum'''
    return a+b
print(add(4,5))