
# if we pass other type of data in any function - suppose a list [1,2,3] - will give error
# so to restrict it to take only int type data - we will make a decorator function *****************************



# long process ---------------------------------------
# from functools import wraps
# def int_only_data(any_func):
#     @wraps(any_func)
#     def wrapper_func(*args,**kwrgs):
#         # first we will run a loop and find data types of all the data in args - then will store them in a list
#         data_type_list = [] # empty list in which data types will be stored ogf all the args datas
#         for i in args:
#             data_type_list.append(type(i) == int) # find the data type of datas in args and == int checks whether data types are int or not
#             #if true - will append  true in the empty list else false
#         # now if all the data types are int - then the list will contains all true value - if so, then only we will proceed to execute the any function
#         if all(data_type_list):
#             return any_func(*args,**kwrgs)
#         else:
#             return "please enter valid argguments"
#     return wrapper_func


# short process -------------------------------------------------using list comprehension
from functools import wraps
def int_only_data(any_func):
    @wraps(any_func)
    def wrapper_func(*args,**kwargs):
        if all([type(i) == int for i in args]):
            return any_func(*args,**kwargs)
        print("please enter valid argguments")
    return wrapper_func


# any function -------------
# to add n numbers
@int_only_data
def addition(*args):
    total = 0
    for i in args:
        total += i
    return total
print(addition(1,2,3,4,[1,2])) # if we pass other type of data - suppose a list [1,2,3] - will give error
# so to restrict it to take only int type data - we will make a decorator function *****************************
