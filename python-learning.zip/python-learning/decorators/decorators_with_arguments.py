# in last example in decorators_practice2 we made a decorator function that only passes int data types
# suppose we want to pass another type of data types - list,string....etc
# in that case we have to make separate decorator function for each type of data type
# to avoid this we will - we will pass arguments in decorator function - that argument will ensure the daat type we want to pass ******
# for this we will have to wrap up the whole decorator function inside a function *****

from functools import wraps
def only_data_type_allow(data_type): # wrapper of decorator - takes argument to define data type
    def decorator_func(any_func):
        @wraps(any_func)
        def wrapper_func(*args,**kwargs):
            if all([type(i) == data_type for i in args]):
                return any_func(*args,**kwargs)
            print("please enter valid argguments")
        return wrapper_func
    return decorator_func # return decorator_function for only_data_type-allow function -*****



# any function ---------- joins as many as strings
@only_data_type_allow(str)
def string_join(*args):
    string = ""
    for i in args:
        string += i
    return string
print(string_join("rahul","kumar",3))
