# define a decoratot - claculate_time - which will calculate the time to run any function

# to calculate time  - we will import time module ----------
# time calculation - t = t2-t1 - t1 is initial time  - t2 is end time - t is total time take n to execute the code
# decorator function --------------------------------

from functools import wraps
import time # importing time module 
def calculate_time(any_func):
    @wraps(any_func)
    def wrapper_func(*args, **kwrgs):
        print(f"here we are executin {sqr_finder.__name__} function")

        t1 = time.time() # initial time - time at which the any function starts running
        returned_value = any_func(*args,**kwrgs) #will not return it- store it in a variable - 
                                                 #otherwise execution will jump outside the function and
                                                 # will not be able to calculate t2
        t2 = time.time() # end time- time at which the any function will end
        total_time = t2 - t1 # time in sec
        print(f"this {sqr_finder.__name__} took {total_time} seconds to execute")

        return returned_value # instead of returning on line number 15 - we are returning the any function here
    return wrapper_func

# any function-----------------------------------

@calculate_time
def sqr_finder(n):
    return [i**2 for i in range(1,n+1)]
sqr_finder(1000)

