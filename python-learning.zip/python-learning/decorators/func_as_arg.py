# map function - here we pass 2 parameters - 1) function, 2)list(iterable) -------------
def square(a):
    return a**2
list1 = [1,2,3,4,5,6,7]
print(list(map(square,list1)))
print(list(map(lambda a:a**2, list1))) # by lambda function


# now we will make our own functin similar to map function that takes a function as parameter----------------------
list2 = [3,4,5,6]
def my_map(func,l): # passing 2 parameters - 1) for function, 2) for list
    new_list = []
    for i in l:
        new_list.append(func(i))
    return new_list
print(my_map(square,list2))
print(my_map(lambda a:a**3,list2))  # by lambda function


# by list comprehension -----------------
list3 = [6,7,8]
def my_map2(func,l):
    return [func(i) for i in l] # list comprehension
print(my_map2(square,list3))
    