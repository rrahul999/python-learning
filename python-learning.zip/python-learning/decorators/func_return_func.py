# normal function ---------
def square(a):
    return a**2 # here instead of returning the formula - we will now return a function *******************************

# function returning function ----------------------
def outer_func(): # no parameter passed
    def inner_func(): # no parameter passed
        print("inside inner function")
    return inner_func # here "outer_func" is returning the "inner_func" - not executing it "inner_func()"
var = outer_func() # here we are calling owr function "outer_func"  -  
# which returns inner function - and inner function is stored in variable 
# now we will call the variable - execute the variable 
var()


# also we can do like this --------------------------
def outer_func(): # no parameter passed
    def inner_func(): # no parameter passed
        print("inside inner function")
    return inner_func() # here we are executing it "inner_func()"
var = outer_func() # here we are calling owr function "outer_func" -which returns inner function -and inner function is stored in variable 
# now we don't need execute the variable 




# another example --------------------------
def outer_func2(msg):   # here w are passing parameter - for example a message
    def inner_func2():
        print(f"message is: {msg}") # using the parameter in outer function
    return inner_func2
var1 = outer_func2("hello world")
var1()