# before learning decorators - first we will learn about ------
# 1) functions
# 2) first class functions/ closures

# normal function ------------- find the square of a number
def square(a):
    return a**2
result = square(7)
print(result)


def square(b):
    return b**2
s = square           # in this case we have assigned the function to  variable "s" - but didn't call the function here
# now we can use the variable "s"  as function 
print(s(7))
print(s.__name__) # will give the name of the function  - which is "square"
print(square.__name__)   # will give the name of the function  - which is "square"
print(s) # will give the memory location here
print(square) # will give the memory location here
# both "s" and the function "square" have the same memory location - since "square" function is assigned to variable "s"

