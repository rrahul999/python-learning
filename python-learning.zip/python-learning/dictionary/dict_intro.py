# dictionaries are used because of limitations of lists
# because lists are not enough to show real life data
# example -------------------
# user = ["rahul", 24,["bokaro", "sector1"],["engineer", "software"]]
# this list consist of user name,age,place,occupation ------ its unstructured data



# dictionary - Unordered collection of data in form of key:value pair
# any complex data can be representrd by dictionary


# how to create dictionary
# user = {"name":"rahul", "age":33}
# print(user)
# print(type(user))


# another method to create dictionary - "dict" method
# user = dict(name = "rahul", age =33)
# print(user)
# print(type(user))


# how to access data from dictionary ----- there is no indexing because of "unordered" collection of data
# in dictionary data can be accessed by "key"
# user = dict(name = "rahul", age =33)
# print(user["name"])


# which type of data can be stored in dictionary - anything
# number, string, list, dictionary
# user_info = {
#     "name": "rahul",
#     "age": 33,
#     "place": ["bokaro", "delhi"],
#     "fav": ["apple", "mango"]
# }

# print(user_info["place"])


# users = {
#     "user1": {
#         "name": "rahul",
#         "age": 33,
#         "place": ["bokaro", "delhi"],
#         "fav": ["apple", "mango"]
#     },
#     "user2": {
#         "name": "rahul kumar",
#         "age": 33,
#         "place": ["gurgaon", "ranchi"],
#         "fav": ["guava", "grapes"]
#     }
# }

# print(users["user1"])
# print(users["user2"])





# how to ad data to empty dictionary
user_info2 = {}
user_info2["name"] = "rahul"
user_info2["age"] = 33
print(user_info2)

