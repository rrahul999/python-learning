# store data from user and store in dictionary
user = {}
name = input("enter name: ")
age = input("enter age: ")
fav_movie = input("enter fav movie separated by comma : ").split(",")
fav_place = input("enter fav place separated by comma : ").split(",")

# by normal way -----
user["name"] = name
user["age"] = age
user["fav_movie"] = fav_movie
user["fav_place"] = fav_place

print(user)

# by looping -------
for key,value in user.items():
    print(f"{key}:{value}")
