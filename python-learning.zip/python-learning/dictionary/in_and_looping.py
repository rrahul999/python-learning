# "in" and "iteration"(looping) in dictionary

user_info = {
    "name": "rahul",
    "age": 33,
    "place": ["bokaro", "delhi"],
    "fav": ["apple", "mango"]
}


# to check if "key" exists in dictionary or not -----------------
# if "name" in user_info:
#     print("yes name is present")
# else:
#     print("not present")


# check if the value exist in dictionary or not ----------------
# if "rahul" in user_info.values():    # we use .values() method
  #     print("yes name value is present")
# else:
#     print("not present")

# if ["bokaro", "delhi"] in user_info.values():    # to check complete list
#     print("yes list value is present")
# else:
#     print("not present")






# looping in dictionary ---------------------
# for i in user_info:
#     print(i)           # will print all the keys


# for i in user_info.values():  # we use .values() method
#     print(i)           # will print all the values
# or
# for i in user_info:
#     print(user_info[i])  # will print all the values


# values method -------------
# user_info_values = user_info.values()
# print(user_info_values)    # shows all the values in list type but not list --- "dict_values"
# print(type(user_info_values)) # dict-values ---these are not lists---data cannot be deleted or removed like list 
#                               # but can iterate through dict_values

# keys method ----------------
# user_info_keys = user_info.keys()
# print(user_info_keys)          # shows all the keys in list type but not list --- "dict_keys"
# print(type(user_info_keys))   # dict_keys ---these are not lists---data cannot be deleted or removed like list 
#                               # but can iterate through dict_keys



# items method ---------------------------------
user_items = user_info.items()
print(user_items)
print(type(user_items))
# it returs a lot of tuples inside a list - [(key,value),(key,value),(key,value),(key,value)]

for key,value in user_info.items():
    print(f"{key}:{value}")


