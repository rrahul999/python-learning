# fromkeys ---------------
# used to create new dictionary -in which we can make desired number "key" to have same "value"
# user  = dict.fromkeys(["name","place","age"],"unknown")   # we can use tuple also
# print(user)
# user1  = dict.fromkeys(("name","place","age"),"unknown")   # tuple
# print(user1)
# user2  = dict.fromkeys("abc","unknown")   # if we use string - a,b,c will be separate key
# print(user2)
# user3  = dict.fromkeys(range(1,11),"unknown")  # if we use range - 1 to 11 will be individual keys 
# print(user3)
# user4  = dict.fromkeys(["name","place","age"],["unknown","unknown"])  # we can use list or tuple in "value" 
# print(user4) # {'name': ['unknown', 'unknown'], 'place': ['unknown', 'unknown'], 'age': ['unknown', 'unknown']}



# get ----------------------- very useful
# can access the value of the key
# user = {
#     "name": "rahul",
#     "age": 33
# }
# # print(user["names"]) # gives key error - -names is not a valid key here
# print(user.get("name"))
# print(user.get("names")) # if there is no valid key in the dictionary -  will not return key error- will return "None"
# # its better way to access value of key

# if "names" in user:
#     print("yes")
# else:
#     print("no")


# if user.get("names"):   # for invalid key "get" method gives "None" and "None" is equal to "false"
#     print("yes")
# else:
#     print("no")






# clear -------------------------
# user = {
#     "name": "rahul",
#     "age": 33
# }
# user.clear() # dictionary will be empty
# print(user)




# copy -------------------------- to make copy of any dictionary - will create separate dictionary
user = {
    "name": "rahul",
    "age": 33
}
user2 = user.copy() # eill create new dictionary - any effect on "user2" will not affect "user"
print(user2)

print(user.popitem())
print(user)
print(user2)