# more about dictionary, if a dictionary have two same key
user = {
    "name": "rahul",
    "name": "kumar",
    "age": 33
}
print(user.get("name")) # if same key wxists -  will return the later one
print(user.get("names")) # if does not find key - will rturn "None"
print(user.get("names", "key not found")) # if does not find key -  and if don't want to return "None" - will return value passed

