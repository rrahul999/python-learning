# word counter
from typing import Counter


def word_counter(word):
    count_word = {}
    for i in word:
        count_word[i] = word.count(i)
    return count_word

print(word_counter("rahul kumar"))
