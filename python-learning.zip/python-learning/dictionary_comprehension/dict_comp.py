# example - square = {1:1,2:4,3:9}   # key value pair - value will be square of key

# square = {i:i**2 for i in range(1,4)}
# print(square)
# for key,value in square.items():  # to print key:value in separate line
#     print(f"{key}:{value}")

# square1 = {f"Square of {i}":i**2 for i in range(1,5)}   # customised key
# print(square1)



# count the character in string ------------------
string = input("enter name : ")
word_counter = {char:string.count(char) for char in string}
print(word_counter)