# DRY ------ don't prepeat yourself

# Modify number guessing game ---------- dry
# guess the number untill you are correct
# number of attempts yo took to win




# by generating random number --------------guessing random number
import random
real_num = random.randint(1,100)
guess = 1
num = int(input("enter a numner: "))
game_over = False
while not game_over:
    if num==real_num:
        print(f"you win in {guess} attempts")
        game_over = True
    else:
        if num > real_num:
            print("too high")
            # guess += 1
            # num = int(input("guess again: "))
        else:
            print("too small")
            # guess += 1
            # num = int(input("guess again: "))
        guess += 1
        num = int(input("guess again: "))