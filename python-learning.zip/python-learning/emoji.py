print("\U0001F92B")
print("\U0001F93B")