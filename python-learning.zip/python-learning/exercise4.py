# Number guessing game using nested if else -------------

winning_num = 9
guessed_num = int(input("enter number: "))
if winning_num == guessed_num:
    print("you won")
else:
    if winning_num > guessed_num:
        print("you entered number is too low ")
    else:
        print("you entered number is too high")