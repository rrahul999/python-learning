# watch coco movie
# ask user name and age
# check if user name starts with "a" or "A" and age is above 10, then "print you can watch movie" else "you cannot watch movie"
  
name, age = input("enter name and age: ").split(",")
age = int(age)
if age >= 10 and (name[0] == "a" or name[0] == "A"):
    print("you can watch movie")
else:
    print("you cannot watch movie")


# check if user name has alphabate "a" or "A" and age is above 10, then "print you can watch movie" else "you cannot watch movie"
name1, age1 = input("enter name and age: ").split(",")
age1 = int(age1)
if age1 >= 10 and (name1.find("a") >=0 or name1.find("A") >= 0):
    print("you can watch movie")
else:
    print("you cannot watch movie")

