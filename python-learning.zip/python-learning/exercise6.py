# # question 1--------------------
# # sum of n natural numbers
# # ask user for n natural numbers and then print the total of 1 to n

# num = int(input("enter number:"))
# total = 0
# i = 1
# while i<=num:
#     total += i
#     i += 1
# print(total)



# # question 2 --------------------
# # ask user to input more than one digit number
# # example 1234
# # calculate 1+2+3+4 and print
# n = input("enter number: ")
# i = 0
# total = 0
# while i<len(n):
#     total += int(n[i])
#     i += 1
# print(total)





# question 3 ----------------------
# ask user to enter name
# example rahul kumar
# print count of each words

name = input("enter name: ")
temp_var = ""
i = 0
while i<len(name):
    if name[i] not in temp_var:
        temp_var += name[i]
        print(f"# {name[i]} {name.count(name[i])}") 
    i += 1

    
