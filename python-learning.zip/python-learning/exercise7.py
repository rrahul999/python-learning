
# while lopop is used when we don't know that how many times the loop will run.-------------------------


# Modify number guessing game
# guess the number untill you are correct
# number of attempts yo took to win
# real_num = 44
# guess = 1
# num = int(input("enter a numner: "))
# game_over = False
# while not game_over:
#     if num==real_num:
#         print(f"you win in {guess} attempts")
#         game_over = True
#     else:
#         if num > real_num:
#             print("too high")
#             # guess += 1
#             # num = int(input("guess again: "))
#         else:
#             print("too small")
#             # guess += 1
#             # num = int(input("guess again: "))
#         guess += 1
#         num = int(input("guess again: "))




# by generating random number --------------
import random
real_num = random.randint(1,100)
guess = 1
num = int(input("enter a numner: "))
game_over = False
while not game_over:
    if num==real_num:
        print(f"you win in {guess} attempts")
        game_over = True
    else:
        if num > real_num:
            print("too high")
            # guess += 1
            # num = int(input("guess again: "))
        else:
            print("too small")
            # guess += 1
            # num = int(input("guess again: "))
        guess += 1
        num = int(input("guess again: "))


# using break ---------------------------
# real_num = 44
# guess = 1
# num = int(input("enter a numner: "))
# game_over = False
# while True:
#     if num==real_num:
#         print(f"you win in {guess} attempts")
#         break
#     else:
#         if num > real_num:
#             print("too high")
#             # guess += 1
#             # num = int(input("guess again: "))
#         else:
#             print("too small")
#             # guess += 1
#             # num = int(input("guess again: "))
#         guess += 1
#         num = int(input("guess again: "))

# using break and continue ----------------
# real_num = 44
# guess = 1
# game_over = False
# while True:
#     num = int(input("enter a numner: "))
#     if num==real_num:
#         print(f"you win in {guess} attempts")
#         break
#     else:
#         if num > real_num:
#             print("too high")
#         else:
#             print("too small")
#         guess += 1
#         continue