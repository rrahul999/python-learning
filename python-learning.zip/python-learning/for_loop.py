
for i in range(10):  # i range is 0 to 9 
    print(f"{i} hi")


for i in range(1, 11):  # i range is 1 to 10 
    print(f"{i} hi")


# sum of numbers from 1 to 10 ------------------------
sum = 0
a, b = input("enter numbers: ").split(",")
a = int(a)
b = int(b)
if b>a:
    for i in range(a, b):
        sum += i
    print(f"the sum is : {sum}")    
else:
    print("first number should be less than 2nd number")


# sum of n natural numbers -----------------------
num = int(input("enter number: "))
total = 0
for i in range(1,num + 1):
    total += i
print(f"The sum of {num} natural numbers = {total} ")
    



# input a number more than 1 digit. i.e- 1234
# find the sum of the number like 1+2+3+4
num = input("enter number: ")
total = 0
for i in range(len(num)):
    total += int(num[i])
print(total)





# print the number of times alphabates in a string is there
# ask user to enter name
# example rahul kumar
# print count of each words
name = input("enter name: ")
temp = ""
for i in range(len(name)):
    if name[i] not in temp:
        temp += name[i]
        print(f"{name[i]} : {name.count(name[i])}")
   





