# earlier we used string in python examples were common in almost all languages
# now we will use some uses of strings that are strictly followed in python only

# normally -------
# name = "rahul"
# for i in range(len(name)):
#     print(name[i])

# strictly in python ----------
name = "rahul"
for i in name:
    print(i)

# sum of 1+2+3=4 
num = input("enter number: ")
total = 0
for i in num:
    total += int(i)

print(total)