# define a function that takes 2 numbers as input and returns greater number

def greatest_num(num1,num2):
    if num1>num2:
        return num1
    return num2
number1, number2 = input("enter numbers: ").split(",")
print(greatest_num(int(number1), int(number2)))