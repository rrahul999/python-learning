# check palindrome
def palindrom(name):
    if name[::-1] == name:
        return "is palindrom"
    return "not palindrom"
print(palindrom("naman"))


def is_palnindrom(name):
    return name == name[::-1] # gives boolean value 
print(is_palnindrom("rahul"))