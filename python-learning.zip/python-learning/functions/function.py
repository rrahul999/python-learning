# add 2 numbers
def sum(num1,num2):   
    return num1+num2
# total = sum(1,2)
# print(total)

a = int(input("enter number1: "))
b = int(input("enter number2: "))
first_name = input("neter forst name: ")
last_name = input("enter last name: ")
total = sum(a,b)
name = sum(first_name,last_name)
print(total)
print(name)



