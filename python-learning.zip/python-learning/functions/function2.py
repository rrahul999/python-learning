# return vs print

#adding 3 numbers 
def add_three(a,b,c):
    return a+b+c
print(add_three(2,2,2))


def add_again(p,q,r):
    print(p+q+r)
add_again(1,1,1)
