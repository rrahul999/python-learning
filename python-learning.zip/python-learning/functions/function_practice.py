# function practice

# 1) pass a parameter and enter a name for that parameter and find out the last alphabate of the string
# def last_index(name):
#     return name[-1]
# username = input("enter name: ")  
# print(last_index(username)) 
# we should pass only relevant values for the parameter, it should be related to the return
#---like here we want to find last index of the string#
# ----so we need to pass only string as a value of the parameter


# 2) find odd or even
# def odd_even(num):
#     if num%2 == 0:
#         return "even"
#     else:
#         return "odd"
# print(odd_even(3))



# 3) is even or not
# def is_even(num):
#     if num%2 == 0:
#         return True
#     else:
#         return False
# number = int(input("enter number: "))
# print(is_even(number))


# def is_even1(num1):
#     return num1%2 == 0  # returns boolean value
# print(is_even1(5))


# 4) functions without any input valu-------wthout any parameter and argument
def song():
    return "hello song"
print(song())