# define a generator function
# take one number as argument
# generate a sequence of even numbers upto that argument

def even_numbers(n):
    for i in range(1,n+1):
        if i%2 == 0:
            yield i
even_num = even_numbers(21)
for i in even_num:
    print(i)