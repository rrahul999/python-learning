# list vs generator
# memory
# time - calculate time - t = t2-t1 - import time module
# when to use list, when to use generators
import time
t1  = time.time()
# l = [i**2 for i in range(10000000)]
g = (i**2 for i in range(10000000))

t2 = time.time()
t = (t2 - t1)
print(t)