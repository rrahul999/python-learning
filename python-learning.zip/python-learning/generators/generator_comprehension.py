# list comprehension ----------
# example to create a list of square of numbers
square = [i**2 for i in range(1,11)]
print(square)


# generator comprehension --------------
square1 = (i**2 for i in range(1,11)) # here we use () parantheses
print(square1)
# here square is now converted into a generator function - now we can iterate over it and demand for output through loop
# for i in square1:
#     print(i)
# for i in square1:
#     print(i)
# will not run more than once


# lets see with next() function  - will show how one number at a time will show
print(next(square1))
print(next(square1))
print(next(square1))
print(next(square1))
print(next(square1))
print(next(square1))
print(next(square1))
print(next(square1))
print(next(square1))
print(next(square1))