# create your first generator with 1)generator function or 2) generator comprehension
# generator gives output only if someone demands.

# example  - print 1 -10
def nums(n): # to print numbers upto "n"
    for i in range(1,n+1):
        yield(i) # since yield is a keyword(not a function) - yield i can also be written
# print(nums(10)) #<generator object nums at 0x00000268C3774890> - yield creates generator
# by using yield keyword - we are making a generator function - now "nums" is a generator  



# now if we run a loop on generator function --------
# for number in nums(10): 
#     print(number) 
# first it will store 1 in memory,then2, then3 and so on - one number at a time in the memory - only when someone demands the numbers
# here the loop is demanding the numbers one by one - so output is 1-10 - first 1, then2 - after getting 2 will remove 1 from memory



numbers = nums(10) # here numbers is a generator now - having numbers 1-10
# if we run a loop for generators - will iterate only once through the loop
for i in numbers:
    print(i)
# if we run a loop again for the genertaor - will not give output  - since generators iterates only once
for i in numbers:
    print(i)



# note - if we want to use our sequence only once - will use generator - else we can convert the generator into a list
# in this case will print the sequence twice  - since "numbers" is no longer generator - now its converte to list
numbers = list(nums(10))
for i in numbers:
    print(i)
for i in numbers:
    print(i)