# generators are iterators

# first we will ltalk about----------------------------------
# iterator, iterable
l = [1,2,3] # iterable
# first we convert the iterable into iterator - by calling iter() function and passing the list into it
# then we call next() function each time - to print the result each time after iteration 
i = iter(l) # here we are calling iter() function to convert the iterable into iterator
print(next(i))
print(next(i))
print(next(i))
# next(l) # we cannot call next function on iterable directly - next() function can be called on iterators only(i.e - iter() function)
# print(next(i)) # it will give error - since the iterable has only 3 values
# this is directly done by for loop also 
for i in l:
    print(i)


# python does not have to change map function into an iterator - map function is already an iterator
map(lambda a:a**2, l) # iterator
# if we will print this map function it will give us MAP OBJECT
print(map(lambda a:a**2, l))


# generally if we run a for loop on iterable(list), then python first convert the iterable(list) into iterator(iter function) - 
# then runs the loop (next function)

# but if we directly runs loop on iterators(map function) - 
# python will not have to convert iterable to iterator since its already an iterator - will run loop directly
for num in map(lambda a:a**2, l):
    print(num)



# generators are iterators
# suppose we make a list - first it will take time to create and then it will be stored in some memory location
# the whole list will be save in a memory location at a time - 
# and whenever we want to iterarte through the list, we will have to go through the whole list - each time
# in case of generator - saved in some memory location - but will generate only one value from the list at a time #############
# so, if we want any previous value again - it won't give  - since it deletes the previous value
# generators are generally used when the list is used only once in its lifetime 

# when there is any requirement to use the values again and again - list is used ***************************
# when there is any requirement to use the values only once - generator is used ***************************
