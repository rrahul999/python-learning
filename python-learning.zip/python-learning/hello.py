print("hello world") 
print("double  \\\\ backslash") 
print("this is/\\/\\/\\/\\/\\ mountain") 
print("hello \t world") 
print("hello \tworld")
print("hello \\\" \\n \\t \\\'  world") 

#to make escape sequence as normal text we use r before statement

print(r"hello \\\" \\n \\t \\\'  sir") 
