
age = int(input("enter your age: "))
if age >= 18:
    print("you are eligible")
else:
    print("you are not eligible")



