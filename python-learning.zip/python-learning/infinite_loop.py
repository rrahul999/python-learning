while True:   # boolean values will start in capital "True" , "False"
    print("hi")