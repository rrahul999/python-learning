
#  int ---converts into integer
#  "4" ----> 4
  
#  str --- converts into string
#  4 ---> "4"

# float --- converts into floating point number
# "4" ---> 4.0

first_num = input("enter first number ")
second_num = input("enter second number ")
total = first_num + second_num
print("total = " + total)     # 33 since it converts both numbers into string first and the concat them

#now the numbers are converted into integer numbers
first_num = int(input("enter first number "))
second_num = int(input("enter second number "))
total = first_num + second_num        # value of total is now an integer number which cannot be concanetated with any string
print("total = " + str(total))        # here str converts the number into string

num = int("2")
num2 = float("3")
add  = num + num2
print("the addition of int and float is = " + str(add)) # 5.0 a float number



