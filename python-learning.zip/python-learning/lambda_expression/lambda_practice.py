# # example 1 -------------------------------------
# def is_even(a):
#     if a % 2 == 0:
#         return True
#     else:
#         return False
# print(is_even(4))


# # shorter way -------
# def is_even1(a):
#     return a%2 == 0 # gives result in boolean
# print(is_even1(3))


# # lambda function ------------
# is_even2 = lambda a : a%2 == 0
# print(is_even2(2))




# # example 2 ---------------------------------------
# # find last character of the string
# #normal method ----------
# def last_char(s):
#     return s[-1]
# print(last_char("rahul"))

# # lambda method ---------
# last_char1 = lambda s : s[-1]
# print(last_char1("sagar"))




# if else with lambda -----------------------------------
# question - is the lenth of the string is greater than 5 or not
# normal method ------------
def func(s):
    return len(s) > 5
print(func("rahul"))

def func1(s):
    if len(s) > 5:
        return True
    return False
print(func1("rahul"))

# lambda method --------------
is_true = lambda s : True if len(s)>5 else False
print(is_true("ashutosh"))

is_true1 = lambda s : len(s)>5
print(is_true1("ashutosh"))