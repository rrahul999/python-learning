fruits = ["apple","orange","grapes","guava","kiwi","banana","papaya"]

# pop method - delete data from last if no argument is passed
fruits.pop()
print(fruits)
print(fruits.pop()) # RETURNS THE VALUE WHICH IS DELETED AND SAVES IT SOMEWHERE FOR FUTURE USE-----
fruits.pop(1) # delete 1st index data
print(fruits)
print(fruits.pop(1))  # RETURNS THE VALUE WHICH IS DELETED AND SAVES IT SOMEWHERE FOR FUTURE USE--------


# del operator/statement ----- delete the data from list whose index is passed in argument
# del fruits[2]
# print(fruits)


# remove method ---------
# fruits1 = ["apple","orange","grapes","guava","kiwi","banana","apple","papaya"]
# fruits1.remove("banana") # will remove banana
# fruits1.remove("apple") # will remove 1st apple
# fruits1.remove("jackfruit") # will give error ----not in list



# for adding data -----append,insert,extend
# for deleting data -----pop,remove,del
