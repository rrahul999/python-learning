# define a function which will take a list containing number as input
# return a list----having values square of the values of first list


number = list(range(1,11))
num = [2,3,4]
def square_num(list1):
    square = []
    for i in list1:
        square.append(i*i) # or i**2
    return square
print(square_num(number))
print(square_num(num))