# define a function that take list of word as argument
# return list with reverse of every element in that list


words = ["pdg","dhr", "ktm"]
def reverse_list(list1):
    reversed = []
    for i in list1:
        reversed_word = i[::-1]
        reversed.append(reversed_word)
    return reversed
print(reverse_list(words))
