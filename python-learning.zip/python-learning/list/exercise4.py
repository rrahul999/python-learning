# define a function that filters odd and even numbers from a list 
# output will have 2 list ----odd list and even list inside a parent list

# numbers = [1,2,3,4,5,6,7,8,9]
# def odd_even(list1):
#     result = []
#     odd = []
#     even = []
#     for i in list1:
#         if i%2==0:
#             even.append(i)
#         else:
#             odd.append(i)
#     result.append(even)
#     result.append(odd)
#     return result
# print(odd_even(numbers))


# with better approach---------------------------
numbers = [1,2,3,4,5,6,7,8,9]
def odd_even(list1):
    odd = []
    even = []
    for i in list1:
        if i%2==0:
            even.append(i)
        else:
            odd.append(i)
    result = [odd,even]   #with better approach -----list inside list
    return result
print(odd_even(numbers))
