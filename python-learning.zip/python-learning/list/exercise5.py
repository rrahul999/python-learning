# define a function which takes 2 list as input and gives 1 list as output
# output should be the common value by comparing the 2 lists in input

# input1 = [1,2,3,4,5]
# input2 = [1,2,6,7,8]
# def common_element(list1,list2):
#     output = []
#     for i in list1:
#         for j in list2:
#             if i == j:
#                 output.append(i)
#     return output
# print(common_element(input1,input2))




# better approach ------------

input1 = [1,2,3,4,5]
input2 = [1,2,6,7,8]
def common_element(list1,list2):
    output = []  
    for i in list1:
        if i in list2:
            output.append(i)
    return output
print(common_element(input1,input2))