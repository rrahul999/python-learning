# count the number of list inside list
from typing import Counter


matrix = [1,2,3,[1,2,3], [4,5,6], [7,8,9],[10]]

def sublist_counter(list1):
    count = 0
    count1 = 0
    for i in list1:
        if type(i) == list:
            count += 1
    return count
print(sublist_counter(matrix)) 


