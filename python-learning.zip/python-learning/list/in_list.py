fruits = ["apple","orange","grapes","guava","kiwi","banana","papaya"]
if "apple" in fruits:  #"in" checks wether apple is there in the list or not
    print("true")
else:
    print("false")
