#list --> data structure --> ordered collection of items
# any thing can be stored in list ex- numbers(float,int),string...
numbers = [1,2,3]
print(numbers)

word = ["rahul", 'kumar',"abc"]
print(word)
print(word[:2]) # will print from 0 index to 1st index(slicing)

mixed = [1,2,'rahul',"kumar",1.2,None]
print(mixed)
mixed[1] = "two"   # changes the value inside list
print(mixed)

mixed1 = [1,2,'rahul',"kumar",1.2,None]
mixed1[1:] = "two"   #all the values from 1st index will be replaced by string "t" "w" "o"---here string breaks & becomes complete list
print(mixed1)
mixed1[1:] = ["apple","mango"] # here list breaks to become new list
print(mixed1)