# split ----converts string to list
user_info = "rahul 33".split() # will splits where there is space in the string
print(user_info)

user1_info = "rahul,34".split(",")# will splits where there is comma in the string
print(user1_info)

name, age = input("enter user info: ").split(",")
print(name)
print(age)




# join ---- converts list to string
user2_info = ["rahul", "33"] # list values should be only string in case of "join"
print(",".join(user2_info)) # list converted into string----and separated by comma
print("/".join(user2_info)) # list converted into string----and separated by /