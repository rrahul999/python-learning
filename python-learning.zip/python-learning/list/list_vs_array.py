# array --- same type(fixed type) of data are stored
# list ---- mixed type of data can be stored---flexible
# javascript array is same as python list
# arraye module of python ----- doesn't comes with python---will have to import---same type(fixed type) of data are stored
# we do not use arrays in python ---instead we use "numpy array"---binding with c library ---so its fast
