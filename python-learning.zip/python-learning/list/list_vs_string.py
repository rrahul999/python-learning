# strings are immutable
# lists are mutable


s = "string" # immutable --- original string cannot be changed(by any string method), if we save it to new string it can be changed
t = s.title() # new string
print(s)  # original string unchanged
print(t) # new string changed


l = ["word1", "word2", "word3"]
l[1] = "word-two" # original list changes----mutable
print(l)
l.pop()  # original list changes----mutable
print(l)
l.append("word4")
l.insert(2,"word3.1")
print(l)