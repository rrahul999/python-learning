fruits = ["apple", "banana", "grapes", "guava", "pears", "kiwi", "mango"]

# for loop
for i in fruits:
    print(i)

# while loop
i=0
while i<len(fruits):
    print(fruits[i])
    i+=1