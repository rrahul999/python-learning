fruits = ["apple","orange","grapes","guava","kiwi","banana","papaya","pear","apple"]


# count method -------
print(fruits.count("apple"))
print(fruits.count("orange"))
print(fruits.count("pineapple"))


# sort method ---------sorts the original list
fruits.sort() # sorts the list alphabatically
print(fruits)

number = [2,4,1,9,5,8] 
number.sort() # sorts in ascending order
print(number)



# sorted function ----------
num = [2,4,1,9,5,8]
print(sorted(num)) # sort the list but does not save the sorted data in the original list----original list remains the same
print(num)

# copy method -----------
num_copy =num.copy()
print(num_copy)

# reverse method -----------
number.reverse()
print(number)


# clear method ----------clears the original list
num1 = [2,5,1,8,3]
num1.clear()
print(num1)