# define a function that take list of strings
# new list containing reverse of every string

# by normal method ---------------
words = ["pdg","dhr", "ktm"]
def reverse_list(list1):
    reversed = []
    for i in list1:
        reversed.append(i[::-1])
    return reversed
print(reverse_list(words))



# by list comprehension --------------
list1 = ["abc", "pqr", "xyz"]
def reverse_list(rev):
    list2 = [i[::-1] for i in rev]
    return list2
print(reverse_list(list1))

list1 = ["abc", "pqr", "xyz"]
def reverse_list2(rev):
    return [i[::-1] for i in rev] 
print(reverse_list2(list1))
