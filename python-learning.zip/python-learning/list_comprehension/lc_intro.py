# with the help of list we can create list in one line

# create a list - square of 1 to 10
# normal method -------
# sq1 = []
# for i in range(1,11):
#     sq1.append(i**2)
# print(sq1)


# list comprehension method ----------
# sq2 = [i**2 for i in range(1,11)]
# print(sq2)



# to create a list of negative number 
# normal method -------------
# neg1 = []
# for i in range(1,11):
#     neg1.append(-i)
# neg1.reverse()
# print(neg1)


# # list comprehension method ----------
# neg2 = [-i for i in range(1,11)]
# print(neg2)



# list one names first charachter will be in list two
names = ["rahul", "kumar", "ritesh", "rohan"]
# normal method ----------
new_list = []
for i in names:
    new_list.append(i[0])
print(new_list)

# list comprehension method ----------------
new_list1 = [i[0] for i in names]
print(new_list1)