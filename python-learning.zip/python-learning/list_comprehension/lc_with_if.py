# list comprehension with if statement

# print even numbers from list

# normal method ----------------
list1 = list(range(1,11))
num = []
for i in list1:
    if i%2 == 0:
        num.append(i)
print(num)

# list comprehension method ----------
num2 = [i for i in list1 if i%2 == 0]
print(num2)
num3 = [i for i in list1 if i%2 != 0]
print(num3)
