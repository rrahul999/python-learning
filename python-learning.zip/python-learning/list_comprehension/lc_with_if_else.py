# list comprehension with if else statement
num = [1,2,3,4,5,6,7,8,9,10]
# make a new list
# if even number - multiply it with 2
# if odd number - make them negative number


# normal method ------------
num1 = []
for i in num:
    if i%2 == 0:
        num1.append(i*2)
    else:
        num1.append(-i)
print(num1)


# by list comprehension method ---------------
def even_odd(list1):
    return [i*2 if i%2 == 0 else -i for i in list1 ]
print(even_odd(num))
