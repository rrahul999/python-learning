# till now we were creating object/instance  - were have a common format  - s1 = Student("raj",4,22) - data in different string
# it was made by predefined  __init__ method/constructor - def __init__(self,names,standards,rolls)
# now to make instance/object by our own way - we need to make our own "constructor" - with the help of decorator "@classmethod"
# class method/constructor can be used to make our own way of instance/object



class Student:
    count = 0 # class variable - also called class attribute
    def __init__(self,names,standards,rolls):
        Student.count += 1 #
        self.name = names
        self.standard = standards
        self.roll = rolls

    # in instance method first argument is instance(object)
    # but in class method first argument is class itself
    # to make a class method - we use a predefined python decorator - @classmethod
    @classmethod
    def count_inatances(cls): # first argument is class itself - cls represents "Student"
        return f"you have created {cls.count} instances of {cls.__name__} class" # counts the class variable(same as Students.count)


    # now we will make our own way of object/instance by using "class method" 
    # example  - to write all the values of the object in single string with comma separated---------
    @classmethod
    def from_string(cls,string): # first argument is class itself- 2nd arg will be whatever we want(here string)
        first,last,age = string.split(",") #defines the variables for the object and splits them with comma
        return cls(first,last,age) # returns the new way(defined by user) to declare the instance/object


    # suppose we want to define another method - "full_name" - it will be defined inside the class only - instance methods
    def full_name(self): # no need to pass any extra arguments - since self already represents instance/object in the init method
        return f"{self.name} {self.standard}"
    
    # another method to check age above 18
    def is_above18(self):
        return self.standard>18 # will give true or false


s1 = Student("raj",4,22)
s2 = Student("rohit",5,21)
s3 = Student("sagar",6,24)
s4 = Student("mohit",2,20)
s5 = Student.from_string("rahul,kumar,32") # creating new way of object/instance - with refrence to  - self defined method/constructor
# s5 = Student("rahul,kumar,32") # if we create like this -  init method will be called

print(Student.count)
print(Student.count_inatances()) # to print the class method output
print(s5.full_name()) # now we can use any earlier defined method - while using the values of new way of object - s5