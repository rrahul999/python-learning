# using class method -  syntax - class_name.class_method()
# make a class method - will return a string saying - "you have created n numbers of instances"

class Student:
    count = 0 # class variable - also called class attribute
    def __init__(self,names,standards,rolls):
        Student.count += 1 #
        self.name = names
        self.standard = standards
        self.roll = rolls

    # in instance method first argument is instance(object)
    # but in class method first argument is class itself
    # to make a class method - we use a predefined python decorator - @classmethod
    @classmethod
    def count_inatances(cls): # first argument is class itself - cls represents "Student"
        return f"you have created {cls.count} instances of {cls.__name__} class" # counts the class variable(same as Students.count)

    # suppose we want to define another method - "full_name" - it will be defined inside the class only - instance methods
    def full_name(self): # no need to pass any extra arguments - since self already represents instance/object in the init method
        return f"{self.fname} {self.lname}"
    
    # another method to check age above 18
    def is_above18(self):
        return self.age>18 # will give true or false


s1 = Student("raj",4,22)
s2 = Student("rohit",5,21)
s3 = Student("sagar",6,24)
s4 = Student("mohit",2,20)

print(Student.count)
print(Student.count_inatances()) # to print the class method output