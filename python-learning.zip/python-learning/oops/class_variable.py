# will make a class - with methods to find area,circumference etc
class Circle:
    def __init__(self,radius,pie):
        # these are instance/object variables
        self.r = radius
        self.pi = pie
    # now we will define our required methods
    def circumference(self):
        return 2*self.pi*self.r
    def area(self):
        return self.pi*self.r**2

cir = Circle(5,3.14)
cir1 = Circle(2,3.14)
# both the circle instances(objects) have same pi value - we are writing it again and again for every objects
# so to avoid this we will define class variable ************************************
print(cir.area())
print(cir.circumference())
print(cir1.area())
print(cir1.circumference())



# example of class variable -------------------------------------------
class Circle2:
    # to avoid writing a common argument for all the objects - will define a class variable here
    pie = 3.14 # "class variable"
    def __init__(self,radius): # no need to pass "pie" argument - as already passed as class variable
        # these are instance/object variables
        self.r = radius
        # here no need to define this - self.pi = pie
    # now we will define our required methods
    def circumf(self):
        # will use class variable now
        return 2*Circle2.pie*self.r # instead of self.pie - will use class variable - Circle2.pie
    def area(self):
        return Circle2.pie*self.r**2

circle1 = Circle2(3) # now here we dont need to pass the pie value - already defined in class variable
circle2 = Circle2(4) # now here we dont need to pass the pie value - already defined in class variable
print(circle1.area())
print(circle1.circumf())




# example 2 of class variable ---------------------------
# need to give a discount of 25% on all products 
class Laptop:
    discount = 50
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        self.price = prices
        self.laptop_name = brands + ' ' + models # we can make "n" numbers of instance variables - and combine any attributes also
    # another method 
    def apply_discount(self): # another argumet is not passed - as its passed in class variable
        off_price = (Laptop.discount/100)*self.price
        return self.price - off_price



lapy1 = Laptop("lenevo","thinkpad",32000)
lapy2 = Laptop("dell","inspiron",42000)

print(lapy1.apply_discount())
print(lapy2.apply_discount())