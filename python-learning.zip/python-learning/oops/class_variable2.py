
#class variables are also called class attributes ***************************************************


# example 3 of class variable ---------------------------
# need to give a discount of 25% on all products  - but want to give differect discount on a particular product
class Laptop:
    discount = 50
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        self.price = prices
        self.laptop_name = brands + ' ' + models # we can make "n" numbers of instance variables - and combine any attributes also
    # another method 
    def apply_discount(self): # another argumet is not passed - as its passed in class variable
        off_price = (self.discount/100)*self.price # make "self.discount" instead of "Laptop.discount" *********************
        return self.price - off_price


# now if we want to change the discount %  - we can change here - by changing the class variable value
# Laptop.discount = 10
lapy1 = Laptop("lenevo","thinkpad",32000)
lapy2 = Laptop("dell","inspiron",42000)
lapy3 = Laptop("hp","pavellion",55000)
# suppose we want to apply a single discount on all products,except on some products - we want to apply different product(object)
lapy4 = Laptop("acer","as-1545",44000)
# will define the different discount here - and make "self.discount" instead of "Laptop.discount" in line no 12
lapy4.discount = 100

print(lapy1.apply_discount())
print(lapy2.apply_discount())
print(lapy3.apply_discount())
print(lapy4.apply_discount())
print(lapy4.__dict__) # will show all the variables in dictionary