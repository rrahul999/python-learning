# encapsulation - to write all the data(details of the object), all the functions used(all the methods) in one place -
# - i.e inside the class is called encapsulation


class Phone:
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        self.__price = prices
    
    def make_a_call(self,phone_number):
        print(f"calling {phone_number}")

    
    def full_name(self):
        return f"{self.brand} {self.model}"


# abstraction - to remove(hide) the complexities of the method used 
# example -----------
# suppose we have a list class - and "l" as its object
l = [3,2,5,1]
# now we will use "sort" method of list class
l.sort() # list class has tim type of sorting
# this tim sorting method has a complex code inside it - but its hidden from the user
print(l) # sorted order




# some special naming convention - _name - convention of private name
# example ->  self._price - its done so that no one changes it 
# __name__ ----- double underscore method - "dunder" method - "magic" method
# suppose we make an object of Phone class
phone1 = Phone("nokia","2500", 2000)
# print(phone1._price)
# # now we can change the price
# phone1._price = 3000
# print(phone1._price)

# naming mangling - __name - this is not a convention - python changes the name -> _class__name
# suppose we write self.__price - and then print this
# print(phone1.__price) # this will give error
# to check what is happening - will print the dict - values of the object
print(phone1.__dict__) # output - {'brand': 'nokia', 'model': '2500', '_Phone__price': 2000}
# here it will change self.__price to - _Phone__price - so that it belongs to this class only ************
# now if we write this - print(phone1._phone__price) - it will give the output
print(phone1._Phone__price)
# WE CAN ALSO CHANGE THE PRICE
phone1._Phone__price = 4000
print(phone1._Phone__price)
