# create a laptop class - with attributes - brand,model,price
# create 2 object/instance of your class

class Laptop:
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        self.price = prices
        self.laptop_name = brands + ' ' + models # we can make "n" numbers of instance variables - and combine any attributes also

lapy1 = Laptop("lenevo","thinkpad",32000)
lapy2 = Laptop("dell","inspiron",42000)

print(lapy1.brand)
print(lapy2.model)
print(lapy2.laptop_name)