# create a laptop class - with attributes - brand,model,price
# create 2 object/instance of your class
# define your own method - "apply_discount" - which will a certain discount on the price - and print the new discounted price

class Laptop:
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        self.price = prices
        self.laptop_name = brands + ' ' + models # we can make "n" numbers of instance variables - and combine any attributes also
    # another method 
    def apply_discount(self,n): # another argumet is passed - "n" - % of discount
        discount = (n/100)*self.price
        return self.price - discount



lapy1 = Laptop("lenevo","thinkpad",32000)
lapy2 = Laptop("dell","inspiron",42000)

print(lapy1.brand)
print(lapy2.model)
print(lapy2.laptop_name)

print(lapy1.apply_discount(50))
print(lapy2.apply_discount(50))