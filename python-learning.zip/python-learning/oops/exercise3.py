# make a class - then make objects(intances) - then count the number of instances made so far of that class - through class variable
# as soon as the instances(objects) are defined - "init" method(constructor) is called first
# so every time an instance(object) is created - "init" method is called - so we can count the number of times it has been called - 
# by increasing the value of class variable by 1 - after constructor(init method) is called
# in order to cont the number of instances(objects)
class Student:
    count = 0 # class variable initially 0
    def __init__(self,names,standards,rolls):
        Student.count += 1 #
        self.name = names
        self.standard = standards
        self.roll = rolls

s1 = Student("raj",4,22)
s2 = Student("rohit",5,21)
s3 = Student("sagar",6,24)
s4 = Student("mohit",2,20)

print(Student.count)