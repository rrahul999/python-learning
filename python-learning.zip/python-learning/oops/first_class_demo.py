# in oops we make our own class - and also make methods for them
# what is class? - its a blueprint - in class we decide what will be our object - what functionalty the object will perform - 
# what will be the attributes of the object


# lets make a classs-------------
# according to convention  - first alphabet of class will be in capital
class Person: # way to define class - after defining class, will define special type of method - "init" method aka - constructor
    def __init__(self,fname,lname,age): # fname,lname,age - attributes of method ---- self represents the object(p1,p2.....)
        print("init method/constructor is called first as soon as the object is created")
        # now we will declare instance(object's) variables
        self.fnames = fname # like p1.fname = fname  - self represents the object(p1,p2.....)
        self.lnames = lname
        self.ages = age

# above we have made our class - "Person" - It have fname,lname,age
# now we will make object of the class "Person" - it will have fname,lname,age
p1 = Person("rahul",";kumar",32)
p2 = Person("sagar","mandhyan",30)
# as soon as the object - her p1 and p2 - are defined - "init" method is called first

print(p1.fnames)
print(p2.fnames)




