
# normal class phone has brand,model,class --------------
class Phone: # base class/ parent class
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        self._price = max(prices,0) 


    def make_a_call(self,phone_number):
        print(f"calling {phone_number}")

    
    def full_name(self):
        return f"{self.brand} {self.model}"


# in addition to variables in phone - smartphone has additional variables also - has its own additional features -----------
# inheritence - inherits all the properties of Phone class to Smartphone class without repeating the valuues
# to do this - we will pass Phone class as argument to the Smartphone class
# there are 2 ways by which -  derived/child class inherits properties of base/parent class 
class Smartphone(Phone): # derived class / child class
    def __init__(self,brands,models,prices,rams,internal_memory,rear_camera):
        # 1st way ----------- uncommon way
        # Phone.__init__(self,brands,models,prices) # by this we call instance variables of Phone class here
        # 2nd way - using super() method ------
        super().__init__(brands,models,prices)  # will not use self here
        self.ram = rams
        self.memory = internal_memory
        self.camera = rear_camera 


phone1 = Phone("nokia","2500", 2000)
smartphone1 = Smartphone("oneplus","six",45000,"8gb","128gb","48mp")
print(phone1.full_name())
print(smartphone1.full_name() + f" and price is {smartphone1._price}") # calling inherited property