# instance(object) methods(function)

# for example -------------
l = [1,2,3]
l.pop() 
# here class = list, instance/object = l, .pop() = method or instance method
# all the function declared in class are called methods


# how to create instance methods --------------
class Person:
    def __init__(self,fnames,lnames,ages): # init method(constructor)- used to create instance/object -first argument represents object
        self.fname = fnames
        self.lname = lnames
        self.age = ages   
    # suppose we want to define another method - "full_name" - it will be defined inside the class only
    def full_name(self): # no need to pass any extra arguments - since self already represents instance/object in the init method
        return f"{self.fname} {self.lname}"
    
    # another method to check age above 18
    def is_above18(self):
        return self.age>18 # will give true or false

p1 = Person("rahul","kumar",32)
p2 = Person("harish","semwal",9)
print(p1.full_name())
print(p2.full_name())
# here at first python calls "Person" class method - "full_name" - and then passes the object "p1/p2" in that method
print(Person.full_name(p2)) # same as print(p2.full_name())

print(p1.is_above18())
print(p2.is_above18())

# for example in list class ------------------------------
l1 = [2,3,4]
# clear method, pop method
l1.clear() # clears the list
# same can be done by this
list.clear(l) # python is calling list class clear method and passing the object l1

# suppose we want to use append method
l1.append(10)
# same can be done by this
list.append(l1,11) # here the first argument is the object - 2nd argument is the value to be passed
print(l1)