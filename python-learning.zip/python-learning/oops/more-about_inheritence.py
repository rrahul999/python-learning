# can we derive more than one class from base class
# multilevel inheritence
# MRO- Method resolution order
# merhod overriding
# 2 builtin functions - 1) isinstance()  2) issubclass()


# normal class phone has brand,model,class --------------
class Phone: # base class/ parent class
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        self._price = max(prices,0) 

    def make_a_call(self,phone_number):
        print(f"calling {phone_number}")
  
    def full_name(self):
        return f"{self.brand} {self.model}"

 
class Smartphone(Phone): # derived class / child class
    def __init__(self,brands,models,prices,rams,internal_memory,rear_camera):
        # 1st way ----------- uncommon way
        # Phone.__init__(self,brands,models,prices) # by this we call instance variables of Phone class here
        # 2nd way - using super() method ------
        super().__init__(brands,models,prices)  # will not use self here
        self.ram = rams
        self.memory = internal_memory
        self.camera = rear_camera 

# can we derive more than one class from base class ===========================================
class Smartphone2(Phone): # derived class / child class
    def __init__(self,brands,models,prices,rams,internal_memory,rear_camera):
        # 1st way ----------- uncommon way
        # Phone.__init__(self,brands,models,prices) # by this we call instance variables of Phone class here
        # 2nd way - using super() method ------
        super().__init__(brands,models,prices)  # will not use self here
        self.ram = rams
        self.memory = internal_memory
        self.camera = rear_camera 
    # merhod overriding ==========================================================
    # here we are inheriting the properties of BASE class
    # but we want to override any of the methods of BASE class
    # suppose here we want to overide "full-name" method of base class by writing another "fullname" method here - called method overriding
    def full_name(self):
        return f"{self.brand} {self.model} {self.ram} {self.memory}"

# multilevel inheritence =============================================================
# will inherit properties of Smartphone class(which already inherited properties of Phone class)
class Flagship_phone(Smartphone2):
    def __init__(self,brands,models,prices,rams,internal_memory,rear_camera,processors):
        super().__init__(brands,models,prices,rams,internal_memory,rear_camera)
        self.processor = processors
    
    # merhod overriding ==========================================================
    # here we are inheriting the properties of BASE class
    # but we want to override any of the methods of BASE class
    # suppose here we want to overide "full-name" method of base class by writing another "fullname" method here - called method overriding
    def full_name(self):
        return f"{self.brand} {self.model} {self.ram} {self.memory} {self.camera}"




phone1 = Phone("nokia","2500", 2000)
smartphone1 = Smartphone("oneplus","six",45000,"8gb","128gb","48mp")
smartphone2 = Smartphone2("apple","XR",65000,"8gb","128gb","64mp")
flagship_phone = Flagship_phone("samsung","f62",30000,"8gb","128gb","64mp","snapdragon")
print(phone1.full_name())
print(smartphone1.full_name() + f" and price is {smartphone1._price}") # calling inherited property
print(smartphone2.full_name() + f" and price is {smartphone2._price}") # calling inherited property
print(flagship_phone.full_name() + f" and price is {flagship_phone._price}") # calling inherited property

# MRO- Method resolution order ==========================================
# every class has MRO - to see MRO of any class we use - help() function
# print(help(Smartphone2)) # its MRO shows the order in which python searches our methods/functions/constructor in that class
# Method resolution order:
#       Smartphone2 - first will check any methods here
#       Phone       - then will check any methods here
#       builtins.object - its a class through which all the builtin mehods of python are derived to other class 

# print(help(flagship_phone))
# we can also write like this -------------- class.mro() ---------# output in list
# we can also write like this -------------- class.__mro__ ---------# output in list



# 1) isinstance() ===============================================
# its used to check wether an instance/object belongs to its class or not - returns true or false
print(isinstance(smartphone1,Smartphone)) # first argument is instance/object,2nd argument is the class
# true - smartphone1 is instance of Smartphone class
print(isinstance(smartphone1,Phone)) # true - smartphone1 is also instance of Phone class - since it inherits Phone class properties
print(isinstance(smartphone1,Flagship_phone)) # false - smartphone1 is not instance of Flagship_phone - 
                                            # since it does not inherits Flagship_phone class properties



# issubclass() ======================================================
# its used to check wether a class(derived/child class) inherits the base/parent class or not - returns boolean values
print(issubclass(Smartphone,Phone)) # 1st argument is the derived class, 2nd argument is the base/parent class
print(issubclass(Smartphone,Flagship_phone)) 