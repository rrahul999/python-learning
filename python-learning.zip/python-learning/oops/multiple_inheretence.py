# multiple inheritence

class A: # no init method defined
    def class_a_method(self):
        return "this is class A method"
    def hello(self):
        return "hello from class A"

instance_a = A()
print(instance_a.class_a_method())

class B: # no init method defined
    def class_b_method(self):
        return "this is class B method"
    def hello(self):
        return "hello from class B"

instance_b = B()
print(instance_b.class_b_method())


# now we will inherit class A and class B into class C
class C(A,B): # just inherit class A and B
    pass # when we do not add any property

instance_c = C()
print(instance_c.class_a_method())
print(instance_c.class_b_method())
print(instance_c.hello()) # will give the first hello method - according to MRO
# print(help(instance_c))
# Method resolution order:
#       C - first will check any methods here
#       A - then will check any methods here - if gets here  - will not check further
#       B - then will check any methods here
#       builtins.object
class D(B,A): # first B then A - now according to MRO - will check B first then A
    pass
instance_d = D()
print(instance_d.hello())
# print(help(instance_d))


# MRO -  we can also write like this -------------- class.mro()
print(C.mro()) # output in list
# MRO -  we can also write like this -------------- class.__mro__
print(D.__mro__) # output in tuple