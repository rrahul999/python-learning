# object oriented programing
# its just a style/way to write a code
# its very helpful in creating real worl programs
# will use these words most in oops - class,object(instance),method


# for example ------------
l = [1,2,3]
l2 = [4,5,6]
l.append(8)
# here in python every thing is considerd as object
# here l and l2 are a kind of object  - of a class - and the class is list
# and the class(here list) have many methods(functions) - here .append() is the method
# if a class has "n" numbers of objects (l1,l2,l3......), all the objects will have all the methods of that class(here list)



# now in oops we will learn how to make our own "class" and "method"

