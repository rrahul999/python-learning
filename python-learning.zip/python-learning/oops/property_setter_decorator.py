# will solve 3 existing problems - through getter,setter decorator
# resolving the issue of setting "price" and "complete specification" of the class
# in other languages we use  - getter() and setter()  methods
# in python we use - "@property" and "@setter" decorators


class Phone:
    def __init__(self,brands,models,prices):
        self.brand = brands
        self.model = models
        # # to set only positive price - we will apply if else condition for price
        # if prices>0:
        #     self._price = prices
        # else:
        #     self._price = 0
        # or we can use this way -----
        self._price = max(prices,0) # max function will set price whichever will be greater between "prices" and "0"
        # self.complete_specification = f"{self.brand} {self.model} = {self._price}"
    
    # making getter() of complete_specification------
    @property # predefined decorator of python  - now "complete_specification" can be used as normal attribute
    def complete_specification(self):
        return f"{self.brand} {self.model} = {self._price}"
    

    # making getter() of price--------
    @property
    def price1(self):
        return self._price
    # now only after making getter() - will make setter() ----------
    @ price1.setter
    def price2(self,new_price):
        self._price = max(new_price,0)

    def make_a_call(self,phone_number):
        print(f"calling {phone_number}")

    
    def full_name(self):
        return f"{self.brand} {self.model}"


phone1 = Phone("nokia","2500", 2000)
# here everything is fine -------
print(phone1.brand)
print(phone1.model)
print(phone1._price)
print(phone1.complete_specification)


# these are 3 issues ------------
phone2 = Phone("moto","razor", -20000) # 1) the price should not be negative
print(phone2.brand)
print(phone2.model)
# suppose we change the price here
# 2) the price should not be negative
phone2._price = -500 # 3) after changing price here,it will change but will not change price at complete_specification
print(phone2._price)
print(phone2.complete_specification) # 3) will show the earlier price only

#1) to set only positive price - we will apply if else condition for price - or maxfunction
#3) when we create an object/instance - init mehod/constructor is called -after that complete_specification instance variable is created 
    # so will give the price defined there for the complete_specification
    # to avoid this  - its better to create a separate method/constructor for complete_specification
    # if we use "property" decorator - we can remove the () - can write like this - print(phone2.complete_specification)
    #  now "complete_specification" method can be used as normal attribute
    # in other languages - its called - "getter()" method - here we use "@property" decorator
# print(phone2.complete_specification())
print(phone2.complete_specification)


#2) now when we defice the price again  - it should not be set to negative
# for this we will first mak getter() then setter() for the price
# after making getter() - using @property decorator  - now we can directly use price - no need to use underscore ********
print(phone2.price1) 
# now will make setter() of "price1" method - and use max() method to compare price  - will not give negative number now


phone2.price2 = 600
print(phone2.price2)
print(phone2.complete_specification)


