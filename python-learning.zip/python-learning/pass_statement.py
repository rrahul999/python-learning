# pass statement simply do nothing ---- if we don't want to run anything inside if block, use pass statement
age = int(input("enter your age: "))
if age >= 18:
    pass


x = 3
if x > 3:
    pass
