# set comprehension is rarely used - generally not used


# example1 - square of 1 to 10
data = {i**2 for i in range(1,11)}
print(data)



# example 2 - make a set of first character of strings inside list
names = ["rahul","aditya","parish","sagar"]
first_char_set = {i[0] for i in names}
print(first_char_set)
