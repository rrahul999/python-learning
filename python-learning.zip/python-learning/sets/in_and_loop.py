s = {1,2,3,4,5,6,"a","b"}


# in keyword is used to chek if item is present or not in set
if "a" in s:
    print("true")
else:
    print("false")



# for loop
for item in s:   # prints all the items in the set - but in unorderd way - random way - because there is no indexing
    print(item)



# set maths - we can perform mathematical operations
s1 = {1,2,3,4}
s2 = {3,4,5,6}
# union
union_set = s1 | s2 # pipe is symbol of union
print(union_set)

# intersection
union_set1 = s1 & s2 # & is symbol of intersection
print(union_set1)