# its unordered collection of unique items - not in key value pair
# s = {1,2,3,2} # data are unique inside sets - removes repeted data
# print(s)
# # unordered - no indexing
# print(s[1]) # will give error



# sets are used to remove duplicate data
# suppose we have a list having duplicate data -  convert it into set to remove duplicate data
# l = [1,1,2,2,3,3,4,4,4,5,5,5]
# s2 = list(set(l)) # here we are using set() function - inside it we are passing the list - and again convert it into list 
# # will give list with only unique data
# print(s2)




# add method --------------------
# s = {1,2,3}
# s.add(4)
# s.add(5)
# s.add(4) # will not add 4 again
# print(s) # {1, 2, 3, 4, 5}


# remove method --------------
# s = {1,2,3}
# s.remove(3) # will remove 3
# print(s)
# s.remove(4) # will give key error
# print(s)


# discard method -------------------
# s1 = {1,2,3}
# s1.discard(2) # it will remove 2 
# s1.discard(5) # will not give key error -  do nothing
# print(s1)


# clear method -----------------------
# s = {1,2,3,4}
# s.clear() # clears the set
# print(s)



# copy method -----------------
# s = {1,2,3,4}
# s1 = s.copy() # co[pies the s to s1
# print(s1)


# we can not store  - list, dictionary, tuple in set ***********************************************************************8
s = {1,1.1,1.0,2.9,2.5, "a"}
print(s) # will not print 1.0 - same as 1 - will print in a any order - unorderd

 