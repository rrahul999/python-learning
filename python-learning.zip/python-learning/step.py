# for i in range(1,11,2):    # moves 2 steps  
#     print(i)

# print 10,9,8......1
for i in range(10,0,-1):
    print(i)