#strings are immutable
name = "rahul"
name1 = name.replace("a", "A") # 
print(name) # name value doesn't change ----- thats why strings are immutable --- name.replace() gets saved in another variable
print(name1) 