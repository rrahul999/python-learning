name = "rahul"
print(name[2]) # print the string in index number 2 
print(name[-1]) # TO PRINT THE LAST STRING IN CASE WE DON'T KNOW THE END POSITION OR LENGTH OF THE STRING

# index value 
#    from starting       from end
# r     0                   -5         
# a     1                   -4
# h     2                   -3
# u     3                   -2
# l     4                   -1 
