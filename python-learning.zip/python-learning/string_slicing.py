name = "rahul"


# index value 
#    from starting       from end
# r     0                   -5         
# a     1                   -4
# h     2                   -3
# u     3                   -2
# l     4                   -1  


print(name[0:3]) # [starting index:stoping index + 1] --- here output is rah
print(name[:]) # will get whole string
print(name[1:]) # will start from index 1 and ends till end
print(name[:3]) # will start from index 0 and ends on index 2
print(name[1:4]) # [starting index:stoping index + 1] --- here output is ahu
print(name[-3:4]) # [starting index:stoping index + 1] --- here output is hul----last index should be from starting to end 


# step argument -------------------------------
print("python"[0:5:2]) #here 2 is step --- output pto
print("pythons"[0::2]) #string starts from 0 index till end--- here 2 is step --- output ptos
print("pythons"[:5:2]) #string starts from 0 index till 4th index--- here 2 is step --- output pto
print("pythons"[::2]) #string starts from 0 index till end--- here 2 is step --- output ptos

# back step argument -------------------------
print("pythons"[3::-1]) #starts from 3rd index and ends on 0 index --- output is htyp
print("pythons"[-1::-1]) #starts from last index and ends on 0 index --- output is in reverse order snohtyp
print("pythons"[::-1]) #starts from last index and ends on 0 index --- output is in reverse order snohtyp  