first_name = "rahul"
last_name = "kumar"
full_name = first_name + " " + last_name # concatination 
print(full_name)
# print(first_name + 3)   gives type error
print(first_name + "3")
print(first_name + str(3))
print(first_name * 3)