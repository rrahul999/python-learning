# function returning two values ---------------

def fun(int1,int2):
    add = int1 + int2
    mul = int1*int2
    return add,mul  # whenever we will return multiple values like this ---- output will be in tuple format
print(fun(2,3))

# ************** here we are using tuple unpacking ***************
addition,multiplication = fun(3,4)
print(addition)
print(multiplication)
