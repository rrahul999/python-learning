# looping in tuple --------- 
# mixed = ("1","2",'3',"4.0")
# for i in mixed:  #we can use while loop also
#     print(i)



# tuple with one element--------------
# num = (1)
# print(type(num))  #<class 'int'>
# word = ("one") 
# print(type(word))  #<class 'str'>
# these are not tuple
# for making tuple we need to add "comma"
# num1 = (1,)
# word1 = ("one",)
# print(type(num1))
# print(type(word1))



# tuple without paranthesis
# fruits = "apple","mango","banana","kiwi"  # by default it becomes tuple
# print(type(fruits))



# tuple unpacking ---------------------
# number of variables should be same as as number of values inside tuple 
# fruits = ("apple","mango","banana","kiwi")
# fruit1,fruit2,fruit3,fruit4= (fruits)
# print(fruit1)
# print(fruit2)
# print(fruit3)
# print(fruit4)



# list inside tuple ------------------
# lists are mutable but tuples are immutable
# lists inside tuple are mutable
# fruits = ("apple","banana",["guava","kiwi"],"pears")
# fruits[2].pop()
# fruits[2].append("grapes")
# print(fruits)




# some functions used inside tuples ---------
# min,max,sum etc
mixed = (1,2,3,4,5)
print(min(mixed))
print(sum(mixed)) # sum function adds all the values inside tuple


