# tuple data structure --- to store data
# like list,tuple can store any data type
# Immutable ---- once created cannot be changed


example = ("one","two","three","four")
# no append,insert,pop,remove
# we use tuple ---- when there is no need to change data
# tuple is faster than list
# methods used in tuple ------ count, index
# functions used in tuple ---- len(example)
# slicing tuple ---- 
print(example[:2])
print(example[2:2])
print(example[2:3])
print(example[1:2])
print(example[::-1])