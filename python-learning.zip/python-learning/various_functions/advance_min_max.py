# numbers = [1,2,3,4,5,6]
# print(min(numbers)) # it finds the minimum of numbers
# print(max(numbers)) # it finds the maximum of numbers


# to find the maximum length of the strings in list ------------------
# names = ["rahul","sagar","harish"]

# def len_func(length): # a normal function to find length
#     return len(length)

# by list comprehension method -----------
# new_list = [i for i in names if i == max(names,key = len_func)]
# print(new_list)

# print(max(names,key = len_func))
# print(min(names,key = len_func))
# here max function will find the string of maximum length
# first parameter is the list into which max function will iterate
# 2nd parameter will be a function - that finds the length of each strings in the list 


# instead of any normal function for length - we can use lambda function ----------
# print(max(names,key = lambda length1:len(length1)))




# to find the student data having maximum score -------------------------------------
# students2 = [
#     {"name":"rahul","score":90,"age":33},
#     {"name":"sagar","score":89,"age":31},
#     {"name":"harish","score":77,"age":28}
# ]


# print(max(students2,key = lambda item:item.get("score")))
# print(max(students2,key = lambda item:item.get("score")).get("name")) # will give only name 
# print(max(students2,key = lambda item:item.get("score"))["name"]) # will give only name 
# print(max(students2,key = lambda item:item.get("score")).get("age")) # will give only age



students = {
    "rahul":{"score":90,"age":33},
    "sagar":{"score":89,"age":31},
    "harish":{"score":77,"age":28}
}
print(max(students,key = lambda item:students[item]['score']))
