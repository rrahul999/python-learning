# where to use "all" and "any" function

# example --------- user will input a list of number - output should be sum of all the numbers --------
# if the user input wrong value - the the "all" "any" fumction will check --------------
# def sum(*args):
#     total = 0
#     for i in args:
#         total += i
#     return total
# print(sum(1,2,3,4))
# print(sum(1,2,3,4,"rahul",["rahul","kumar"])) # unsupported operand type(s) for +=: 'int' and 'str'


def sum1(*args):
    total = 0
    # since input will be converted into tuple for "args" - (1,2,3,"rahul",["rahul","kumar"])
    # we will check the type of the input first  - to avoid wrong input
    if all([(type(arg) == int or type(arg) == float) for arg in args]):
        for i in args:
            total += i        
        return total
    else:
        return "please pass valid input"
    
print(sum1(1,2,3,4))
print(sum1(1,2,3,4,"rahul",["rahul","kumar"]))