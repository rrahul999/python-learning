# enumerate function is used with for loop to track "position of our item" in iterable


# # without enumerate function -------------------
names = ["rahul","sagar","harish"]  # output pattern should be 0 - rahul, 1 - sagar, 2 - harish
# pos = 0  # counter for position of string in list
# for i in names:
#     print(f"{pos} - {i}")
#     pos += 1



# # with enumerate function ----------------------
# for pos,i in enumerate(names):  # more than one variables in for loop, here in the parameter we can pass the list directly
#     print(f"{pos} - {i}")
  



# define a function that takes 2 parameters - 1)list containing string, 2)string that we want to find in our list
# and this function will return the index of the string in our list
# and if string is not present will return -1
def find_string(list1,string1):
    for pos,i in enumerate(list1):
        if i == string1:
            return pos
    return -1

print(find_string(names,"harish"))