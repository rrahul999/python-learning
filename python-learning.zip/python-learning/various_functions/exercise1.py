# define a function - take any number of lists containing numbers
# [1,2,3] [4,5,6] [7,8,9] .....
# find the average of each lists - (1+4+7)/3 (2+5+8)/3 (3+6+9)/3
# try to make it anonymous function - lambda function

# without lambda function ---------------------
# num1 = [1,2,3]
# num2 = [4,5,6]
# def avg_finder(l1,l2):
#     avg = []
#     for pair in zip(l1,l2):
#         avg.append(sum(pair)/len(pair))
#     return avg
# print(avg_finder(num1,num2))

# with *args for n numbers of lists --------------------------------
# def avg_finder(*args):
#     avg = []
#     for pair in zip(*args): # *args - unpacking of tuples
#         avg.append(sum(pair)/len(pair))
#     return avg
# print(avg_finder([1,2,3],[4,5,6],[7,8,9])) # passing arguments here will give args a group of tuples i.e - ([], [], [])


# with lambda function -----------------------------
avg1 = lambda *args:[sum(pair)/len(pair) for pair in zip(*args)]
print(avg1([1,2,3],[4,5,6]))