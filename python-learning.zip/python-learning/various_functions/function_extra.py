# doc strings - it shows us the docs about the various functions(len,sorted,min,max,sum....etc) - syntax - .__doc__
# used defined docstrings are written in tripple quotation ("""abc""") or ('''abc''')
print(len.__doc__)
print(sorted.__doc__)
print(sum.__doc__)
print(max.__doc__)

# user defined function -------
def add(a,b):
    """sum of 2 numbers""" 
    return a+b
print(add.__doc__) # will show the doc about add function




# help function - it gives us information about function - same as doc string
print(help(sum))