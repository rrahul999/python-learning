# iterators_vs_iterable

numbers = [1,2,3,4] # iterables
sq = map(lambda i:i**2,numbers) # iterators
print(sq)

