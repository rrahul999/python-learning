# to create l1 = [1,3,5] and l2 = [2,4,6] from list = [(1,2),(3,4),(5,6)] - reverse process
# using * operator with zip ------------
list1 = [(1,2),(3,4),(5,6)]
print(list(zip(*list1))) # will convert the given list into 2 tuples 
l1,l2 = list(zip(*list1)) # will make 2 separate lists l1 and l2
print(list(l1)) # converting into list
print(l2)

list2 = [(1,4,7),(2,5,8)]
print(list(zip(*list2))) # will convert the given list into 3 tuples




# to check greater number between given lists and store in new list ----------
l3 = [1, 3, 5]
l4 = [2, 4, 6]
new = []
for pair in zip(l3,l4): # here pair is - (1,2) (3,4) (5,6)
    new.append(max(pair)) # to find the max number between pair
print(new)
