# check 2 conditions at same time ------

# and
name = "rahul"
age = 33
if name == "rahul" and age == 33:
    print("condition true")
else:
    print("condition false")


if name == "rahul" or age == 34:
    print("condition true")
else:
    print("condition false")