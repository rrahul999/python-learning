def multiply_num1(*args):
    print(args)
    multiply = 1
    for i in args:
        multiply *= i
    return multiply

num = [1,2,3,4]
print(multiply_num1(num)) # here we are passing [1,2,3,4] as argument - so, 1*[1,2,3,4] = [1,2,3,4]
# for this we have to unpack the list
print(multiply_num1(*num)) # "*num" - unpack the list or tuple -  to 1,2,3,4
