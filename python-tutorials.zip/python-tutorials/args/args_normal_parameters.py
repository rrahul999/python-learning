# args with normal parameters

# multiplication of numbers
def multiply_num(*args):
    multiply = 1
    for i in args:
        multiply *= i
    return multiply


print(multiply_num(1, 2, 3, 4))


# there are 2 parameters "nums" and "*args" ----------------------
# def multiply_num1(nums,*args):
#     print(nums)
#     print(args)
#     multiply = 1
#     for i in args:
#         multiply *= i
#     return multiply
# print(multiply_num1(2,3,4)) # arguments passed here will divide into 2 parts - for "nums" and "*args"
# 2 will be part of "nums" - will not be included in tuple passed for "*args"
# 3,4 will become tuple and will be argument for "*args"


# def multiply_num1(num1,*args):
#     print(args)
#     multiply = 1
#     for i in args:
#         multiply *= i
#     return multiply
# print(multiply_num1(2)) # if only one argument is passed - it will be part of normal parameter "num1" - "*args" will be empty tuple


# if normal parameter "num1" is passed but no argument is passed - will give error - we can keep the argument for "*agrs" empty
# - but cannot keep arguments for normal parameters "num1" empty
# def multiply_num1(num1, *args):
#     print(args)
#     multiply = 1
#     for i in args:
#         multiply *= i
#     return multiply
# print(multiply_num1())






# - we can keep the argument for "*agrs" empty
# - but cannot keep arguments for normal parameters "num1" and "num2" empty
# def multiply_num1(num1,num2, *args):
#     print(args)
#     multiply = 1
#     for i in args:
#         multiply *= i
#     return multiply
# print(multiply_num1(1,2))




# normal parameters are not passed after "*args"
def multiply_num1(*args , num1):
    print(args)
    multiply = 1
    for i in args:
        multiply *= i
    return multiply
print(multiply_num1(1,2)) # any argument defined here will become tuple for "*args" - will not be assigned for normal parameter "num1"
