name = "rahul"
# name = name + " kumar"
name += " kumar"
print(name) 