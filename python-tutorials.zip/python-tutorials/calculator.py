print(2+3)
print(8-5)
print(2*3)
print(10/5) # float division 2.0
print(10/7) # float division 
print(5/10) # float division 0.5
print(10//5) # integer division 2
print(10//7) # integer division
print(5//10) # integer division 0
print(10%2) # modulo gives reminder 0
print(2**3) # exponent 8
print(2**0.5) # sq root 1.4142135623730951
print(round(2**0.5, 4)) # sq root upto 4 digit
print((2+4)/6*2) 

