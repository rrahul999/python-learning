# add and delete data -------------------

user_info = {
    "name": "rahul",
    "age": 33,
    "place": ["bokaro", "delhi"],
    "fav": ["apple", "mango"]
}


# how to add data -----------------------
# user_info["fav_song"] = ["song1", "song2"]
# print(user_info)


# how to remove data -----------------------
# 1) pop method
# popped_data = user_info.pop("fav")   # stores popped data in variable
# print(popped_data)    # print the popped data in list
# print(type(popped_data))    # will return a list
# print(user_info)

# 2) popitem method   - used to delete any random key value pair

popped_item  = user_info.popitem()   #here we do not pass any parameter - it will delete any random key value pair
print(user_info)
print(popped_item)    #print the popped data in tuple
print(type(popped_item))    # will return a tuple
