# define a function that takes a number (n)
# return a dictionary - cubes of numbers in key value pair
# example - 1:1,2:8,3:27 and so un upto n

def cube_root(n):
    cubes = {}
    for i in range(1,n+1):
        cubes[i] = i**3
    return cubes


print(cube_root(3))
