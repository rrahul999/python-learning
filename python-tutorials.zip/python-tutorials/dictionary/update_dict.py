user_info = {
    "name": "rahul",
    "age": 33,
    "place": ["bokaro", "delhi"],
    "fav": ["apple", "mango"]
}

more_info = {
    "name" : "kumar",
    "state": "jharkhand",
    "game": ["football", "cricket"]
}


# user_info.update(more_info) # existing name will also be updated
user_info.update({}) # if we do not pass any dictionary inside update -  nothing will happen - output will be the original dictionary
print(user_info)