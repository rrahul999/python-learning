# input 3 numbers in one line only with comma separated
# TAKE OUT THE AVERAGE OF THE 3 NUMBERS
# print the average using string formatting 

# Solution --------------------------------------------------------
num1, num2, num3 = input("enter 3 numbers").split(",")
avg =(int(num1) + int(num2) + int(num3))/3
print("the average of the numbers is {}".format(avg))
print(f"the average of the numbers is {avg}")