name = input("enter your name ")
print(f"your name in reverse order is {name[::-1]} " )