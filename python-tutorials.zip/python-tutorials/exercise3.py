# take 2 comma separated input from user, string and a character of that string
# output = 1)length of string , 2)number of count of entered character of the string

name, char = input("please enter name and alphabate:- ").split(",")
print(f"length of the user name is: {len(name)}")
print(f"count of {char} is: {name.lower().count(char.lower())}")
print(f"count of {char.strip()} is: {name.strip().lower().count(char.strip().lower())}") # strip removes all the spaces form left and right
