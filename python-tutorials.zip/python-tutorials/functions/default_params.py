# def user(fname,lname,age):
#     print(f"fname is : {fname}")
#     print(f"lname is : {lname}")
#     print(f"age is : {age}")
# user("rahul","kumar",33)


# def user(fname,lname,age=34): #we can pass argument for parameters here --------- called default parameter
#     print(f"fname is : {fname}")
#     print(f"lname is : {lname}")
#     print(f"age is : {age}")
# user("rahul","kumar")  #arguments can pe skipped if its declared in parameter

# def user(fname,lname,age=34): #we can pass argument for parameters here --------- called default parameter
#     print(f"fname is : {fname}")
#     print(f"lname is : {lname}")
#     print(f"age is : {age}")
# user("rahul","kumar",33)  #arguments passed here will over write the default parameter


# def user(fname,lname,age=None): #we can pass argument for parameters here---called default parameter--"None" is a predefined value which means "nothing"
#     print(f"fname is : {fname}")
#     print(f"lname is : {lname}")
#     print(f"age is : {age}")
# user("rahul","kumar")  #arguments can pe skipped if its declared in parameter

# def user(fname,lname = "kumar",age = None): #default parameters should not be followed by normal parameter
#     print(f"fname is : {fname}")
#     print(f"lname is : {lname}")
#     print(f"age is : {age}")
# user("rahul")  #arguments can pe skipped if its declared in parameter


# def user(fname,lname = "kumar",age): #default parameters should not be followed by normal parameter
#     print(f"fname is : {fname}")
#     print(f"lname is : {lname}")
#     print(f"age is : {age}")
# user("rahul",33)  #will show error


def user(fname = "rahul",lname = "kumar",age = None): #default parameters should not be followed by normal parameter , if not, then will show error
    print(f"fname is : {fname}")
    print(f"lname is : {lname}")
    print(f"age is : {age}")
user()  #arguments can pe skipped if its declared in parameter