def greater(a,b):
    if a>b:
        return a
    return b



def greatest(a,b,c):
    if a>b and a>c:
        return a
    elif b>a and b>c:
        return b
    return c


def new_greatest(a,b,c):
    bigger = greater(a,b) # calling the "greater function" here---greater number will be saved in "bigger" variable
    return greater(bigger,c)
print(new_greatest(10,20,30))

# for 4 numbers
def new_greatest(a,b,c,d):
    bigger = greater(a,b) 
    bigger1 = greater(bigger,c)
    return greater(bigger1,d)
print(new_greatest(10,20,30,40))

def new_greatest(a,b,c,d):
    big = greatest(a,b,c) 
    return greater(big,d)
print(new_greatest(40,50,60,70))