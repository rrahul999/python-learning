# find greatest number between 3 numbers

def greater(a,b,c):
    if a>b and a>c:
        return a
    elif b>a and b>c:
        return b
    return c
num1 = int(input("num1: "))
num2 = int(input("num2: "))
num3 = int(input("num3: "))
greatest = greater(num1,num2,num3)
print(f"{greatest} is greatest")