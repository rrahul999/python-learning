# x=5  # global variable
# def func():
#     x=7  # local variable
#     return x
# print(func()) # 7
# print(x) # 5




# x=5  # global variable
# def func():
#     global x # using global variable x here
#     x=7  # local variable
#     return x
# print(func()) # 7
# print(x) # 7




x=5  # global variable
def func():
    global x # using global variable x here
    x=7  # local variable
    return x
print(x) # 5 ------here the function is not called first, so the value of x is not changed
print(func()) # 7
print(x) # 7