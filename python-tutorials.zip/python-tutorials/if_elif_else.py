# shoe ticket price --------
# age 1 - 10 , free
# age 11 - 20 ,50
# age 21- 35 , 70
# age 36 and above ,80

age = int(input("enter age: "))
if age <= 0:
    print("invalid age")
elif 0<age<=10:
    print("entry fee: free")
elif 10<age<=20:
    print("entry fee: 50")
elif 20<age<=35:
    print("entry fee: 70")
else:
    print("entry fee: 80")