# if with in -----------------


name, string = input("enter name and string: ").split(",")
string = string.strip().lower()
name = name.strip().lower()
if string in name:           # "in" keyword finds whether there is entered string in name or not
    print(f"{string} is in {name}")
else:
    print(f"there is no {string} in {name}")