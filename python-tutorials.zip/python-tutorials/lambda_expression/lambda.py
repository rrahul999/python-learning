# lambda expressions - anonymous function - it has no name

# normal function -----------------
def add(a,b):
    return (a+b)
print(add(2,3))

# lambda function --------------------
add1 = lambda a,b : a+b  # here lambda function is assigned to a variable
# generally we do not assign lambda function to any variable
# we use lambda functions with built in functions like map, filter, reduce etc
print(add1(2,4))

multiply = lambda a,b : a*b
print(multiply(2,5))
