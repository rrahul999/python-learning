# how to add data to list

fruits = ["apple","mango"]
fruits.append("grapes") # append method will add items to the list at the last
print(fruits)

fruits1 = [] # we can take empty list also
fruits1.append("apple")
fruits1.append("mango")
print(fruits1)
