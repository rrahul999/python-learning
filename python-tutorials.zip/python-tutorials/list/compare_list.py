# for comparing list we use == and "is" keyword
fruits1 = ["apple","mango","guava"]
fruits2 = ["kiwi","banana","pears"]
fruits3 = ["apple","mango","guava"]

print(fruits1 == fruits2) # gives boolean output
print(fruits1 == fruits3) # == checks wether the values of both the list are same or not
print(fruits1 is fruits3) # results false--- is checks wether both the lists are in same memory place or not 
