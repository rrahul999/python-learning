
# insert method --- can insert data in the list at any position
# fruit = ["apple","mango"]
# fruit.insert(1,"grapes") # will add data in index 1
# fruit.insert(20,"guava") # if the position is  not there in the list ----will add data at last
# print(fruit)



# concatenate ----------- adds and save data in new list 
# fruit1 = ["apple","mango"]
# fruit2 = ["grapes","guava"]
# fruits = fruit1 + fruit2
# print(fruits)


# extend method ---------adds and save data in same list
fruit1 = ["apple","mango"]
fruit2 = ["grapes","guava"]
fruit1.extend(fruit2) # if we use append---fruit2 list will append inside fruit1 list ---['apple', 'mango', ['grapes', 'guava']]
print(fruit1) # ['apple', 'mango', 'grapes', 'guava']
print(fruit2)
