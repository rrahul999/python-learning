# define a function which will take a list containing number as input
# reverse the list values


# reverse method ----------
number1 = [1,2,3,4,5,6,7,8,9]
def reverse_num1(list1):
    return list1.reverse()
print(reverse_num1(number1)) # output is "None"

number2 = [1,2,3,4,5,6,7,8,9]
def reverse_num1(list2):
    list2.reverse() #first we reverse then return
    return list2   
print(reverse_num1(number2))

# by list slicing method ------------same as string slicing
number3 = [1,2,3,4,5,6,7,8,9]
def reverse_num1(list3):
    return list3[::-1]  
print(reverse_num1(number3))


# by append pop method -------------------------
number4 = list(range(1,11))
def reverse_num(list4):
    rev_list= []
    for i in range(len(list4)):
        rev = list4.pop()
        rev_list.append(rev)
    return rev_list
print(reverse_num(number4))