matrix = [[1,2,3], [4,5,6], [7,8,9],[10]] # its called 2d list
print(matrix[0]) # [1,2,3]
print(matrix[1][1]) # 5
for i in matrix:
    for j in i:
        print(j)




# type function
s = "rahul"
print(type(s))
print(type(matrix))