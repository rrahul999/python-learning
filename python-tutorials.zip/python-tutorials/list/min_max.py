# min function ----- finds smallest number from list
# max function ----- finds greatest nimber from list


numbers = [1,3,6,23,55,22,11]
print(min(numbers))
print(max(numbers))

# find difference between min and max numbers
def difference(list1):
    return max(list1) - min(list1)
print(difference(numbers))
