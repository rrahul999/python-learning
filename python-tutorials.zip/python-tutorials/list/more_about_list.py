# generate list with range function ---------------
numbers = list(range(1,11)) # range function inside list function
print(numbers)

#pop method -----------------
print(numbers.pop()) # RETURNS THE VALUE WHICH IS DELETED AND SAVES IT SOMEWHERE FOR FUTURE USE


# index method ---------------------
number1 = [1,2,3,4,5,6,1]
print(number1.index(1)) # will gives the index position of first 1
# number.index(a,b,c)
# a = the number whose index position we want to search 
# b = the index position from where we want to search "a" again in the list
# c = the index position upto which we want to stop our search



# Pass list to a function -------------
# print list with negative values by passing a positive value list
num = [1,2,3,4,5,6,7]
def negative_list(list1): # parameter passed here will take a "list" as argument---list is passed inside function
    negative = []
    for i in list1:
        negative.append(-i)
    return negative
print(negative_list(num)) 

