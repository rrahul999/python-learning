# define a function 
# input list should contain mixed data types
# output list should convert only the number into string

info_data = [True, False,"a","b",1,1.0,2]
def string_data(list1):
    return [str(i) for i in list1 if type(i) == int or type(i) == float ]
print(string_data(info_data))
