# create nested list through list comprehension
example = [[1,2,3], [1,2,3], [1,2,3]]
# to create a list [1,2,3] and repeat itself n number of times

# def nested_list(list1):
#     return [[i for i in range(1,4)] for j in list1]
# print(nested_list(list(range(1,4))))


num = [[i for i in range(1,4)] for j in range(3)]
print(num)