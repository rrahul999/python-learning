name = "rahul"
age = 33
broage = 30
print("hello my name is " + name + " and my age is " + str(age)) # ugly syntax


# using format method concatenate ----avoids using + everytime 
# uses {}-----called placeholder
print("hello my name is {} and my age is {}".format(name, age)) # used in python 3
print("hello my name is {} and my age is {}".format(name, age + 1)) # calculations can also be done
print("hello my name is {1} and my age is {2} and broage is {0}".format(name, age, broage)) # we can change the position by changing index number 
print("my age is {0:f} and broage is {1:f}".format(age, broage)) # {index:float} --->converts integer into float  
print("my age is {0:.3f} and broage is {1:.2f}".format(age, broage)) # {index:.number float} --->.number restrict digits after decimal 
print("my age is not {} ".format(age/18)) # after decimal 16 digits ---> called DOUBLE FLOAT NUMBER 
print("my age is not {0:f} ".format(age/18)) # after decimal 16 digits ---> called DOUBLE FLOAT NUMBER --->can be converted to float by "f" 
print("my age is {0:4d} ".format(age)) # index:x space} --->x = number of space = number of space we want + number of digit of age
print("my name is {0:>7} ".format(name)) # <> is used for right and left space in string {index:space x} --->x = number of space = number of space we want + length of string of name
print("my name is {0:*^11s} ".format(name)) # ***rahul*** --->name in center with * sign on both side starting from right side

# inside loop ---------
for i in range(10):         # here loop runs from 0 to 9
    print("{} {} {}".format(i, i**2, i**3))

for i in range(1, 10):      #here loop runs from 1 to 9
    print("{} {} {}".format(i, i**2, i**3))

#-------------------------------------

print(f"hello my name is {name} and my age is {age}") # f is used in starting of string --- used in python 3.6 and above
print(f"hello my name is {name} and my age is {age + 1}") # calculations can also be done
