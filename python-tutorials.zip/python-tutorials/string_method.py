# string methods --------------------
name = "rAhuL KumAR"

# len() function
print(len(name)) # counts the length of the string including space



# methods are used by dot(.)
# lower() method
print(name.lower()) # converts string into lower case

# upper() method
print(name.upper()) # converts string into upper case

# title() method
print(name.title()) # converts firts character into capital

# count() method
print(name.count("A")) # counts number of A present in string
