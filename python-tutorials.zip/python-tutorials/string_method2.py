

# replace() ----------------
string = "is he is running hi all what is going on he is running"

print(string.replace(" ", "_")) #replaces all apace with _
print(string.replace("is", "was")) #replaces all "is" with "was"
print(string.replace("is", "was", 1)) #replaces only 1 "is" starting from left with "was"




# find()--------------- finds the position of any character in string
print(string.find("is")) # finds the starting index of first is from left to right---output is 0
print(string.find("is", 1)) # finds the starting index of first "is" from left to right---output = 26 -----finds "is" starting from index 1



# how to find the position of 2nd "is" when we don't know the position of 1st "is"
string1 = "he is running hi all what is going"

first_is_position = string1.find("is") # its a number---position of first "is" 
print(string1.find("is", first_is_position + 1))



# center method --------------similar to string formatting --- print("my name is {0:*^11s} ".format(name))
name = "rahul"
print(name.center(9, "*")) # 1st argument = length of string + number of * we want , 2nd argument = * 

# to add # when we don't know the input/input length
name1 = input("enter name: ")
print(name1.center(len(name1) + 6, "#"))

