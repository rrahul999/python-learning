# strip method is used to remove spaces in string

name = "  RaAhul  "
name1 = "      ra    hul     "
dots = "............"
print(name + dots) # a lot of spaces are there

# lstrip() --- removes spaces from left
print(name.lstrip() + dots)

# rstrip() --- removes spaces from right
print(name.rstrip() + dots)

# strip() --- removes  spaces from left and right only 
print(name.strip() + dots) 

# replace() --- removes all spaces
print(name1.replace(" ", "") + dots) # rplaces all spaces " " with no space ""

