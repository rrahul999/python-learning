# something more about tuples,lists,str

# num = tuple(range(1,11)) # we can write tuples by range also ---- range function inside tuple
# print(num)



# convert tuple into list------------
# num = list((1,2,3,4,5,6,7))
# print(num)


# convert tuple into string -------
num1 = str((1,2,3,4))
print(num1)  # output looks like tuple but actually it is string = "(1, 2, 3, 4)" ************************
print(type(num1))

# convert lists into string -------
num_list = str([1,2,3,4,5])
print(num_list)  # output looks like lists but actually it is string = "(1, 2, 3, 4)"*************************
print(type(num_list))



