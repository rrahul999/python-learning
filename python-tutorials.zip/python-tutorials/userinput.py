name = input("enter your name:-")
print("hi" + " " + name)
age = input("enter your age:-")
print("age is" + " " + age) # age is converted into string so that string is concatinated with string


# print two or more inputs in one line-------------------------
name, age = input("enter your name and age ").split() # input separated by space
print(name + " " + age)

name, age = input("enter your name and age separated by comma ").split(",") # input separated by comma
print(name + " " + age)
