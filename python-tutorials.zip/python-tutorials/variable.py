num = 2
print(num) # 2
num = 4
print(num) # 4

#2
#4
name = "rahul"
print(name) # rahul
name = 123
print(name) # 123


# declearing multiple variables in one line-------------------------------

name, age = "rahul" , "33"
print("my name is " + name + "and my age is " + age)
name, age = "rahul" , 34
print("my name is " + name + "and my age is " + str(age))

x=y=z=2
print(x+y+z)