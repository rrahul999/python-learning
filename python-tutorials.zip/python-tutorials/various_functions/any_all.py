# to find all the numbers in list are even or not 
num1 = [2,3,4,6,8,9]
num2 = [2,4,6,8]

# normal method -------------
# even_list = []
# for i in num1:
#     if i%2 == 0:
#         even_list.append(True)
#     else:
#         even_list.append(False)
# print(even_list)

# with all function ---------------"all" checks that all values in the iterable are true or false
# even_list = []
# for i in num1:
#     if i%2 == 0:
#         even_list.append(True)
#     else:
#         even_list.append(False)
# print(all(even_list))

# with "all" function along with list comprehension ----------------- "all" checks that all values in the iterable are true or false
# print(all([True,True,True])) # true
# print(all([True,True,False])) # false
# print(all([i%2==0 for i in num1]))
# print(all([i%2==0 for i in num2]))

# with any function - "any" function checks - wether thre is any true or not  -----------------------
print(any([i%2==0 for i in num1]))




