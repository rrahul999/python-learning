# filter function
# first parameter is any function or any defined formula
# 2nd parameter is list,tuple etc
def is_even(a): # function for even and odd - return true and false based on input
    return a%2 == 0

numbers = [1,2,3,4,5,6,7,8,9] 
output = list(filter(is_even,numbers)) 
print(output)
output = tuple(filter(is_even,numbers)) 
print(output)
output = list(filter(lambda a:a%2!=0,numbers)) 
print(output)


numbers1 = [1,2,3,4,5,6]
evens = filter(lambda a:a%2==0,numbers1) # it will give filter object - which is iterable - we can iterate through it
for i in evens:
    print(i)
# we can iterate through map/filter object only onnce *****************************
for j in evens: # if we run the loop again for filter/map object - it will not run - to run we have to convert filter/map object to list/tuple
    print(i)

evens = list(filter(lambda a:a%2==0,numbers1))
print(evens)





# by list comprhension ------------------
new_even = [i for i in numbers if i%2==0 ]
print(new_even)
