# find square of items in list
numbers = [1,2,3,4]
def square(a): # here we define a general funtion for square of numbers - "a" is the item in the list 
    return a**2

output = list(map(square,numbers))  # 1st parameter is the function(formula), 2nd parameter is list 
                                    # here we iterate "a" with "map function" in the list(numbers)
print(output)




# by lambda function ---------------
# numbers = [1,2,3,4,5]
# output = list(map(lambda a:a**2,numbers)) # with lambda function -  we don't need to define separate function(formula)
# print(output)
# ***********************************************************************************
# here in map function we pass 2 arguments - #
# 1) what we want to do with the item in the list - generally any function returning any formula
# 2) the list,tuple etc itself





# by list comprehension ---------------
# sq_new = [i**2 for i in numbers]
# print(sq_new)



# without list comprehension and map function ----------------------
new_list = []
for i in numbers:
    new_list.append(square(i))   # here we pass a general funtion for square of numbers - defined earlier
print(new_list)

# number1 = [1,2,3,4,5,6]
# square2 = []
# for i in number1:
#     square2.append(i**2)
# print(square2)


# number2 = [1,2,3,4,5,6,7]
# def find_sq(list1):
#     square3 = []
#     for i in list1:
#         square3.append(i**2)
#     return square3
# print(find_sq(number2))
        




# another map example -------------------------------
names = ["rahul","sagar","harish"]
length = map(len,names) # find the length of each string in the list
print(type(length))
print(length)  # it will give a map object - it is also iterable - so now we will iterate thorough it  *************************
for i in length:
    print(i)