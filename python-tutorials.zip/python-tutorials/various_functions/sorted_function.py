# sort - sort the string alphabatically
# sort - sort the number 
# sort - it only sorts the lists 
fruits = ["apple","grapes","banana"]
fruits.sort() # sort the list alphabatically
print(fruits) # original list will be changed - will be sorted

fruits1 = ("apple","grapes","banana")
# fruits1.sort() # since tuple is immutable, so it can not be "sort"
# print(fruits1)
# to sort tuple we use sorted() function
print(fruits1) # original list is not sorted - tuple is immutable 
new_fruit = sorted(fruits1) # after sorting - saved in new list 
print(new_fruit) 


fruits2 = {"apple","grapes","banana"} # sorted function is also used with sets
print(sorted(fruits2)) # output will be in any order, since sets gives unordered list
print(fruits2) # will not change the original list



# sorting copmlex data structure ---------------------------
bikes = [
    {"model":"RE","year":1901},
    {"model":"HH","year":1900},
    {"model":"YA","year":1940}
]
# sort according to year
print(sorted(bikes,key = lambda d:d["year"])) 
print(sorted(bikes,key = lambda d:d["year"],reverse=True))  # it will reverse the dictionary
