user = ["user1","user2","user3"]
names = ["rahul","sagar","harish"]
# zip function will give a "zip object(iterator)" which will contain "tuple" - ("user1","rahul"),("user2","sagar"),("user3","harish")
# these iterators can be converted into list or tuples
print(zip(user,names)) # it gives zip object - iterator - we can iterate through it
print(list(zip(user,names)))
print(tuple(zip(user,names)))
print(dict(zip(user,names))) # will convert into dictionary



# dictonary conversion -------------
info = [("a",1),("b",2)] # dict converts tuples inside list into dictionary
print(dict(info))


user1 = ["user1","user2"]
names1 = ["rahul","sagar","harish"]
print(list(zip(user1,names1))) # output will according to user1 - will ot print "harish"




user2 = ["user1","user2","user3"]
names2 = ["rahul","sagar","harish"]
last_name = ["kumar","mandhyan","semwal"]
print(list(zip(user2,names2,last_name)))
