# while lopop is used ehen we don't know that how many times the loop will run.


# i = 1
# while i<=10:
#     print(f"{i}) hi")
#     i += 1    # i = i + 1 



# sum of numbers using while loop
total = 0
i = 1
while i<=10:
    total += i
    i += 1   
print(f"the sum is: {total}")